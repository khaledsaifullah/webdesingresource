<?php include 'header.php'; ?>

<!-- dash popup Modal start -->
<div id="dash-popup" class="dash-model modal fade show" role="dialog" style="display:block">
    <div class="modal-dialog dash-popup-model">
        <!-- Modal content-->
        <div class="modal-content">
		  <div class="email-header">
               Image Upload  <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
			          <div class="file-upload-block single-option browsewrap">
                        <div class="file-upload">
                            <div class="file-upload-text"><span><i class="fi fi-upload"></i> Upload</span></div>
                            <input type="file">
                        </div>
                     </div>
                      <div class="dash-thumbnail-wrap">
			               <div class="thumbnail-item">
                              <div class="thum-picture"><img src="images/our-services/studio.png" alt="studio"></div>
                           </div>
						   
						   <div class="thumbnail-item">
                              <div class="thum-picture thumactive"><img src="images/our-services/rings.png" alt="studio"></div>
                          </div>
						  
						   <div class="thumbnail-item">
                              <div class="thum-picture"><img src="images/our-services/studio.png" alt="studio"></div>
                           </div>
						   
						    <div class="thumbnail-item">
                              <div class="thum-picture"><img src="images/our-services/studio.png" alt="studio"></div>
                           </div>
						   
						    <div class="thumbnail-item">
                              <div class="thum-picture"><img src="images/our-services/studio.png" alt="studio"></div>
                           </div>
						   
						    <div class="thumbnail-item">
                              <div class="thum-picture"><img src="images/our-services/studio.png" alt="studio"></div>
                           </div>
						   
						    <div class="thumbnail-item">
                              <div class="thum-picture"><img src="images/our-services/studio.png" alt="studio"></div>
                           </div>
						   
						    <div class="thumbnail-item">
                              <div class="thum-picture"><img src="images/our-services/studio.png" alt="studio"></div>
                           </div>
						   
						    <div class="thumbnail-item">
                              <div class="thum-picture"><img src="images/our-services/studio.png" alt="studio"></div>
                           </div>
						   
						    <div class="thumbnail-item">
                              <div class="thum-picture"><img src="images/our-services/studio.png" alt="studio"></div>
                           </div>
						   
						    <div class="thumbnail-item">
                              <div class="thum-picture"><img src="images/our-services/studio.png" alt="studio"></div>
                           </div>
						   
						    <div class="thumbnail-item">
                              <div class="thum-picture"><img src="images/our-services/studio.png" alt="studio"></div>
                           </div>
                     </div>
               </div>
			  <div class="selectbtn-wrap"> <button type="button" class="btn btn-primary pribtn selectbtn">Select</button></div>
         </div>

    </div>
</div>
<!-- dash popup Modal end -->

<?php include 'footer.php'; ?>
