$(document).ready(function(){
    initUI();
    $(document).click( function (e) {
        var _target = $(e.target);
        var toggleShow = _target.closest(".toggle-class:not(.no-auto)");
        if(!toggleShow.length){
            $(".toggle-class:not(.no-auto)").each(function(){
                var c = $(this).attr("toggle-class");
                $(this).removeClass(c);
            })
        }


        // var rightSidebar = _target.closest(".right-sidebar");
        // if(!rightSidebar.length && !_target.hasClass("topbar-filter") && !_target.parent().hasClass("topbar-filter")){
        //     var filter_fly = $(".right-sidebar");
        //     filter_fly.animate({right: '-100%', opacity: '0'}, "slow");
        //     $('body').removeClass('advanced-filter-fly');
        // }

        return true;
    });


    // Notification
    $(document).on('click', '.notification .notification-icon', function () {
        $('.notification-section').toggleClass('show');
    });

    // Toggle Class
    // Parent class: toggle-show/open/on... Action class: toggle-click/hover...
    // $(document).on('click', '.close-sidebar', function () {
    //     var _this = $(this);
    //     var toggle_parent = _this.closest(".sidebar")
    //     toggle_parent.toggleClass("open");
    // });
    $(document).on('click', '.toggle-click', function () {
        var _this = $(this);
        var toggle_parent = _this.closest(".toggle-class")
        var toggle_class = toggle_parent.attr("toggle-class");
        $('.toggle-class').each(function(){
            if($(this).is(toggle_parent)){
                toggle_parent.toggleClass(toggle_class);
            } else {
                var c = $(this).attr("toggle-class");
                $(this).removeClass(c);
            }
        })
    });
    $(document).on('mouseenter', '.toggle-hover', function () {
        var _this = $(this);
        var toggle_parent = _this.closest(".toggle-class")
        var toggle_class = toggle_parent.attr("toggle-class");
        $('.toggle-class').each(function(){
            if($(this).is(toggle_parent)){
                toggle_parent.toggleClass(toggle_class);
            } else {
                var c = $(this).attr("toggle-class");
                $(this).removeClass(c);
            }
        })
    });


    //Advanced Filter
    $(document).on('click', '.topbar-filter', function () {
        var filter_fly = $(".right-sidebar");
        filter_fly.animate({right: '0', opacity: '1'}, "500");
        $('body').addClass('advanced-filter-fly');
    })
    $(document).on('click', '.sidebar-close', function () {
        var filter_fly = $(".right-sidebar");
        filter_fly.animate({right: '-100%', opacity: '0'}, "slow");
        $('body').removeClass('advanced-filter-fly');
    })
    $(document).on('click', '.search-cancel-btn', function () {
        var filter_fly = $(".right-sidebar");
        filter_fly.animate({right: '-100%', opacity: '0'}, "slow");
        $('body').removeClass('advanced-filter-fly');
    })
    $(document).on('click', '.search-reset-btn', function () {
        var f = $(this).closest('form');
        var f = $(".right-sidebar").find('form');
        f[0].reset();
        if(f.length){
            $(".search-submit-btn",$(".right-sidebar")).trigger('click')
            // $.trigger('click',$(".search-submit-btn",f));
        }
    })
});

function initUI() {
    initDatePicker();
    initSelectDropDown();
    initToggle();
    initScroll();
}

function initSelectDropDown(){
    // Custom Drop Down
    $('.custom-dropdown').chosen({
        width: 'auto',
        disable_search_threshold: 5
    });
}

function initScroll(){
    // Custom Scroll
    $('.scroll, .chosen-container .chosen-results').each(function(){
        new PerfectScrollbar(this, {
            wheelSpeed: 2,
            // wheelPropagation: true,
            // minScrollbarLength: 20
        });
    });
}

function initToggle(){
    $('.tree-toggle').click(function () {
        $(this).parent().toggleClass("on").children('ul.tree').toggle(200);
    });
    $('.tree-toggle').parent().children('ul.tree').toggle(200);
}

function prepareDatePicker(_this){
    var d = new Date();
    // return "datetimepicker-" + d.getTime() + d.getMilliseconds() + Math.floor(Math.random()*10+99);
    if($(_this)[0].localName == "div"){
        var id = $(_this).attr('id');
        if(!id){
            var id = "datetimepicker-" + d.getTime() + d.getMilliseconds() + Math.floor(Math.random()*10+99);
            $(_this).attr('id',id);
        }
        $(_this).children().attr('data-toggle','datetimepicker').attr('data-target',"#"+id);
        $(_this).attr('data-target-input','nearest').attr('data-target',"#"+id);
        $(_this).find('input').addClass("datetimepicker-input");
    } else if($(_this)[0].localName == "input"){
        var id = $(_this).attr('id');
        if(!id){
            var id = "datetimepicker-" + d.getTime() + d.getMilliseconds() + Math.floor(Math.random()*10+99);
            $(_this).attr('id',id);
        }
        $(_this).attr('data-toggle','datetimepicker').attr('data-target',"#"+id);
        $(_this).addClass("datetimepicker-input");
        $(_this).closest('div').children().attr('data-toggle','datetimepicker').attr('data-target',"#"+id);
    }

    return id || false;

}

function initDatePicker(){


    // Date Picker
    $('.date-picker:not(.datetimepicker-init)').each(function(){
        $(this).addClass("datetimepicker-init");
        setTimeout(function(_this){
            var id = prepareDatePicker(_this);
            var option = {
                format: 'DD/MM/YYYY',
                icons: {
                    previous: 'fi fi-left-arrow',
                    next: 'fi fi-right-arrow',
                    today: 'fi fi-calendar',
                    close: 'fi fi-close'
                }
            };
            if($(_this).attr('data-datepickeroptions')){
                option = $.extend(option, $(_this).data('datepickeroptions'));
            }

            if($(_this).attr('minDate')){
                option.minDate = $(_this).attr('minDate')
            }

            if($(_this).attr('maxDate')){
                option.maxDate = $(_this).attr('maxDate')
            }
            if(id != false){
                $("#"+id).datetimepicker(option);
            }
        },100,this);
    })

    // Time Picker
    $('.time-picker:not(.datetimepicker-init)').each(function(){
        $(this).addClass("datetimepicker-init");
        setTimeout(function(_this){
            var id = prepareDatePicker(_this);
            var option = {
                format: 'LT',
                icons: {
                    up: 'fi fi-up-arrow',
                    down: 'fi fi-down-arrow'
                }
            };

            if($(_this).attr('data-datepickeroptions')){
                option = $.extend(option, $(_this).data('datepickeroptions'));
            }

            if($(_this).attr('minDate')){
                option.minDate = $(_this).attr('minDate')
            }

            if($(_this).attr('maxDate')){
                option.maxDate = $(_this).attr('maxDate')
            }

            if(id != false){
                $("#"+id).datetimepicker(option);
            }
        },100,this);
    })

    // Date/Time Picker
    $('.date-time-picker:not(.datetimepicker-init)').each(function(){
        $(this).addClass("datetimepicker-init");
        setTimeout(function(_this){
            var id = prepareDatePicker(_this);
            var option = {
                format: 'DD/MM/YYYY LT',
                icons: {
                    time: 'fi fi-circular-clock-outline',
                    date: 'fi fi-calendar',
                    up: 'fi fi-up-arrow',
                    down: 'fi fi-down-arrow-2',
                    previous: 'fi fi-left-arrow',
                    next: 'fi fi-right-arrow',
                    today: 'fi fi-calendar',
                    clear: 'fi fi-refresh',
                    close: 'fi fi-close'
                }
            };
            if($(_this).attr('data-datepickeroptions')){
                option = $.extend(option, $(_this).data('datepickeroptions'));
            }

            if($(_this).attr('minDate')){
                option.minDate = $(this).attr('minDate')
            }

            if($(_this).attr('maxDate')){
                option.maxDate = $(_this).attr('maxDate')
            }
            if(id != false){
                $("#"+id).datetimepicker(option);
            }
        },100,this);
    })

}

//bottom to top button
$(document).ready(function(){
    jQuery('#scroll-top').bind('click', function () {
        jQuery('html, body').animate({ scrollTop: 0 }, 2500);
        return false;
    });
});

// Plaques details product slider start
$('#plaque-product-slider').owlCarousel({
    loop:true,
    margin:10,
    nav:false,
    autoplay:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
})
var owl = $('#plaque-product-slider');
owl.owlCarousel();
// Go to the next item
$('.customNextBtn').click(function() {
    owl.trigger('next.owl.carousel');
})
// Go to the previous item
$('.customPrevBtn').click(function() {
    // With optional speed parameter
    // Parameters has to be in square bracket '[]'
    owl.trigger('prev.owl.carousel', [300]);
})

// Plaques details product slider end