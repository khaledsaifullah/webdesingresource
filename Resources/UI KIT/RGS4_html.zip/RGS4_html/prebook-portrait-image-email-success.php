<?php include 'header.php'; ?>
<!--Start-body-->
<div class="body-content">

    <div class="container content-wrap">
        <div class="breadcum-wrap">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Plaque</a></li>
                <li class="breadcrumb-item"><a href="#">Walnut & Gold Plaque</a></li>
            </ol>
        </div>
        <h1 class="title-text">Prebook portrait image - <span>$175.00</span> </h1>
        <div class="plaques-details-page">
            <div class="row">
                <div class="col-sm-5 col-md-12 col-lg-5">
                    <div class="plaque-product-slider">
                        <div id="plaque-product-slider" class="owl-carousel owl-theme">
                            <div class="item">
                                <img src="./images/products/product-img.jpg" alt="">
                            </div>
                            <div class="item">
                                <img src="./images/products/product-photo.jpg" alt="">
                            </div>
                            <div class="item">
                                <img src="./images/products/product-img.jpg" alt="">
                            </div>
                            <div class="item">
                                <img src="./images/products/product-photo.jpg" alt="">
                            </div>
                        </div>
                        <div class="owl-nav">
                            <div class="customNextBtn"></div>
                            <div class="customPrevBtn"></div>
                        </div>
                        <div class="option-icons">
                            <a href="#" class="star-icon"></a>
                            <a href="#" class="message-icon"></a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-5 col-md-12 col-lg-7">
                    <form action="">
                        <div class="product-options mt-0">
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <div class="radio-container-box">
                                            <div class="radio-container">
                                                <label for="">Prebook stage photo and save X%</label>
                                                <span class="custom-radio right">
                                                    <input type="radio" id="r-1" name="r-1" checked>
                                                    <label for="r-1">$45.00</label>
                                                </span>
                                            </div>
                                            <div class="box-container">
                                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting
                                                    industry. Lorem Ipsum has been the industry's standard dummy text
                                                    ever since the 1500s.</p>
                                                    <div class="form-group">
                                                    <div class="input-group">
                                                        <div class="input-group">
                                                            <div class="date-picker date-time-normal">
                                                                <input type="text"
                                                                    placeholder="Select ceremony date and time" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="notify-meesage">
                                        <span>Add email address of your friends/family who you want to share the proofs
                                            with, and email will be sent once the proofs are ready? (Optional) </span>
                                    </div>
                                    <div class="form-group">
                                    <div class="input-group">
                                        <input type="email " class="form-control" placeholder="Enter email address">
                                        <div class="input-group-append">
                                            <span class="input-group-text searchbtn">SEND <i class="fi fi-arrow-thin-right goarrow"></i></span>
                                        </div>
                                        <div class="success-msg">Your email has been sent successfully</div>
                                    </div>
                                </div>
                                </div>
                              
                            </div>
                        </div>
                        <button type="button" class="btn btn-primary normalbtn-lg w100">Add to Cart <span
                                class="btn-right-arrow"></span></button>
                    </form>
                </div>
            </div>
        </div>

        <div class="freq-ask-qus">
            <h2 class="title">Frequently Asked Questions</h2>
            <div id="accordion">

                <div class="row">
                    <div class="col-sm-6">
                        <div class="card">
                            <div class="card-header" id="heading-1">
                                <h5 class="mb-0">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapse-1"
                                        aria-expanded="false" aria-controls="collapse-1">
                                        Where does it come from?
                                    </a>
                                </h5>
                            </div>
                            <div id="collapse-1" class="collapse" data-parent="#accordion" aria-labelledby="heading-1">
                                <div class="card-body">
                                    Text 1
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading-2">
                                <h5 class="mb-0">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapse-2"
                                        aria-expanded="true" aria-controls="collapse-2">
                                        What is Lorem Ipsum?
                                    </a>
                                </h5>
                            </div>
                            <div id="collapse-2" class="collapse show" data-parent="#accordion"
                                aria-labelledby="heading-2">
                                <div class="card-body">
                                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                    Ipsum has been the industry's standard dummy text ever since the 1500s.
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading-3">
                                <h5 class="mb-0">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapse-3"
                                        aria-expanded="false" aria-controls="collapse-3">
                                        Where does it come from?
                                    </a>
                            </div>
                            <div id="collapse-3" class="collapse" data-parent="#accordion" aria-labelledby="heading-3">
                                <div class="card-body">
                                    Text 3
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="card">
                            <div class="card-header" id="heading-4">
                                <h5 class="mb-0">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapse-4"
                                        aria-expanded="false" aria-controls="collapse-4">
                                        Where does it come from?
                                    </a>
                            </div>
                            <div id="collapse-4" class="collapse" data-parent="#accordion" aria-labelledby="heading-4">
                                <div class="card-body">
                                    Text 3
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading-5">
                                <h5 class="mb-0">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapse-5"
                                        aria-expanded="false" aria-controls="collapse-5">
                                        Where does it come from?
                                    </a>
                            </div>
                            <div id="collapse-5" class="collapse" data-parent="#accordion" aria-labelledby="heading-5">
                                <div class="card-body">
                                    Text 3
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading-6">
                                <h5 class="mb-0">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapse-6"
                                        aria-expanded="false" aria-controls="collapse-6">
                                        Where does it come from?
                                    </a>
                            </div>
                            <div id="collapse-6" class="collapse" data-parent="#accordion" aria-labelledby="heading-6">
                                <div class="card-body">
                                    Text 3
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading-7">
                                <h5 class="mb-0">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapse-7"
                                        aria-expanded="false" aria-controls="collapse-7">
                                        Where does it come from?
                                    </a>
                            </div>
                            <div id="collapse-7" class="collapse" data-parent="#accordion" aria-labelledby="heading-7">
                                <div class="card-body">
                                    Text 3
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<!--Start-end-->
<?php include 'footer.php'; ?>