<?php include 'header.php'; ?>
<!--Start-body-->
<div class="body-content">
<div class="container content-wrap">
    <div class="thank-you-area">
	<div class="inside-border">
	<h4>You have successfully placed your order</h4>
	<p>You will receive order confirmation email shortly. If you have not received the email, please check your junk folder. If you have created an account, you can view your order history by
	going to my account page and by clicking on history</p>
	<div class="order-details">
	<h5>Your Order Details</h5>
	<p>Order ID: #025</p>
	<p>Email: example@reedgraduations.com</p>
	<a href="">Download Invoice</a>
	</div>
	</div>
	</div>
</div>
</div>
<!-- email popup Modal end -->
<?php include 'footer.php'; ?>
