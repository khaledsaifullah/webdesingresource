<?php include 'header.php'; ?>
<!--Start-body-->
<div class="body-content">

    <div class="container content-wrap">
        <div class="breadcum-wrap">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Plaque</a></li>
                <li class="breadcrumb-item"><a href="#">Walnut & Gold Plaque</a></li>
            </ol>
        </div>
        <h1 class="title-text">View / Order stage video - <span>$30.00</span> </h1>
        <div class="plaques-details-page">
            <div class="heading-title">
                <h3>Build-A-Pak</h3>
                <div class="offer-title">
                    <span class="active">Buy 2-3 Photos and Get 10% </span> | 
                    <span>Buy 4-5 Photos and Get 15% </span> | 
                    <span>Buy 6 or more Photos and Get 20% </span>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-5 col-md-12 col-lg-5">
                    <div class="plaque-frame-slider">
                        <div id="plaque-frame-slider" class="">
                            <div class="item">
                                <img src="./images/products/View-Order-without-frame.jpg" alt="">
                            </div>
                        </div>
                        <div class="frame-nav">
                            <div class="customNextBtn"></div>
                            <div class="customPrevBtn"></div>
                        </div>
                        <div class="thumnail-slide">
                            <div class="item-list">
                                <img src="./images/products/View-Order-frame-thumbnail.jpg" alt="">
                            </div>
                            <div class="item-list">
                                <img src="./images/products/View-Order-frame-thumbnail.jpg" alt="">
                            </div>
                            <div class="item-list active">
                                <img src="./images/products/View-Order-frame-thumbnail.jpg" alt="">
                            </div>
                            <div class="item-list">
                                <img src="./images/products/View-Order-frame-thumbnail.jpg" alt="">
                            </div>
                            <div class="item-list">
                                <img src="./images/products/View-Order-frame-thumbnail.jpg" alt="">
                            </div>
                            <div class="item-list">
                                <img src="./images/products/View-Order-frame-thumbnail.jpg" alt="">
                            </div>
                            <div class="item-list">
                                <img src="./images/products/View-Order-frame-thumbnail.jpg" alt="">
                            </div>
                        </div>
                        <div class="range">
                             <input type="range" min="1" max="100" value="50" class="slider-range" id="myRange">
                             <p>3/20</p>
                        </div>
                        <div class="option-icons">
                            <a href="#" class="star-icon"></a>
                            <a href="#" class="message-icon"></a>
                        </div> 
                    </div>
                </div>
                <div class="col-sm-5 col-md-12 col-lg-7">
                    <form action="">
                        <div class="product-options mt-0">
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label>Select your format</label>
                                        <select class="custom-dropdown">
                                            <option>Print</option>
                                            <option>A4</option>
                                            <option>A5</option>
                                            <option>A6</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="select-options">
                                        <div id="so-accordion">
                                            <div class="row no-gutters">
                                                <div class="col-sm-12">

                                                    <div class="card">
                                                        <div class="card-header" id="so-1">
                                                            <h5 class="mb-0">
                                                                <a class="collapsed" role="button"
                                                                    data-toggle="collapse" href="#so-1collapse-1"
                                                                    aria-expanded="true" aria-controls="so-1collapse-1">
                                                                    Select size
                                                                </a>
                                                            </h5>
                                                        </div>
                                                        <div id="so-1collapse-1" class="collapse show"
                                                            data-parent="#so-accordion" aria-labelledby="so-1">
                                                            <div class="card-body">
                                                                <table class="table">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td>10 x 30 cm</td>
                                                                            <td>$90.00</td>
                                                                            <td>
                                                                               
                                                                            </td>
                                                                            <td>
                                                                                <div class="form-group">
                                                                                    <span class="custom-radio right">
                                                                                        <input type="radio" id="r-1" name="select-size">
                                                                                        <label for="r-1"></label>
                                                                                    </span>
                                                                                </div>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>10 x 30 cm</td>
                                                                            <td>$90.00</td>
                                                                            <td>
                                                                                <div class="qty">
                                                                                    <button
                                                                                        class="increase-qty">-</button>
                                                                                    <span>2</span>
                                                                                    <button
                                                                                        class="increase-qty">+</button>
                                                                                </div>
                                                                            </td>
                                                                            <td>
                                                                                <div class="form-group">
                                                                                    <span class="custom-radio right">
                                                                                        <input type="radio" id="r-2"  name="select-size1">
                                                                                        <label for="r-2"></label>
                                                                                    </span>
                                                                                </div>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>10 x 30 cm</td>
                                                                            <td>$90.00</td>
                                                                            <td>
                                                                                <div class="qty">
                                                                                    <button
                                                                                        class="increase-qty">-</button>
                                                                                    <span>2</span>
                                                                                    <button
                                                                                        class="increase-qty">+</button>
                                                                                </div>
                                                                            </td>
                                                                            <td>
                                                                                <div class="form-group">
                                                                                    <span class="custom-radio right">
                                                                                        <input type="radio" id="r-3" name="select-size2">
                                                                                        <label for="r-3"></label>
                                                                                    </span>
                                                                                </div>
                                                                            </td>
                                                                        </tr>

                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="card">
                                                        <div class="card-header" id="AEO">
                                                            <h5 class="mb-0">
                                                                <a class="collapsed" role="button"
                                                                    data-toggle="collapse" href="#so-2collapse-2"
                                                                    aria-expanded="false"
                                                                    aria-controls="so-2collapse-2">
                                                                    Artistic effects (Optional)
                                                                </a>
                                                            </h5>
                                                        </div>
                                                        <div id="so-2collapse-2" class="collapse"
                                                            data-parent="#so-accordion" aria-labelledby="AEO">
                                                            <div class="card-body">
                                                            Artistic effects (Optional) gose here..
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="card">
                                                        <div class="card-header" id="FOO">
                                                            <h5 class="mb-0">
                                                                <a class="collapsed" role="button"
                                                                    data-toggle="collapse" href="#so-2collapse-3"
                                                                    aria-expanded="false"
                                                                    aria-controls="so-2collapse-3">
                                                                    Frame option (Optional)
                                                                </a>
                                                            </h5>
                                                        </div>
                                                        <div id="so-2collapse-3" class="collapse"
                                                            data-parent="#so-accordion" aria-labelledby="FOO">
                                                            <div class="card-body">
                                                            Frame option (Optional) gose here..
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="card">
                                                        <div class="card-header" id="BOO">
                                                            <h5 class="mb-0">
                                                                <a class="collapsed" role="button"
                                                                    data-toggle="collapse" href="#so-2collapse-4"
                                                                    aria-expanded="false"
                                                                    aria-controls="so-2collapse-3">
                                                                    Bundle option (Optional)
                                                                </a>
                                                            </h5>
                                                        </div>
                                                        <div id="so-2collapse-4" class="collapse"
                                                            data-parent="#so-accordion" aria-labelledby="BOO">
                                                            <div class="card-body">
                                                            Bundle option (Optional) gose here..
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div> 
                                </div>
                            </div>
                            </div>

                            <div class="row">
                                <div class="col-sm-12 col-md-12 col-xs-12">
                                    <button type="button" class="btn btn-primary normalbtn-lg w100">Add to Cart <span
                                            class="btn-right-arrow"></span></button>
                                </div>
                            </div>

                    </form>
                </div>
            </div>
        </div>

        <div class="freq-ask-qus">
            <h2 class="title">Frequently Asked Questions</h2>
            <div id="accordion">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="card">
                            <div class="card-header" id="heading-1">
                                <h5 class="mb-0">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapse-1"
                                        aria-expanded="false" aria-controls="collapse-1">
                                        Where does it come from?
                                    </a>
                                </h5>
                            </div>
                            <div id="collapse-1" class="collapse" data-parent="#accordion" aria-labelledby="heading-1">
                                <div class="card-body">
                                    Text 1
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading-2">
                                <h5 class="mb-0">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapse-2"
                                        aria-expanded="true" aria-controls="collapse-2">
                                        What is Lorem Ipsum?
                                    </a>
                                </h5>
                            </div>
                            <div id="collapse-2" class="collapse show" data-parent="#accordion"
                                aria-labelledby="heading-2">
                                <div class="card-body">
                                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                    Ipsum has been the industry's standard dummy text ever since the 1500s.
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading-3">
                                <h5 class="mb-0">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapse-3"
                                        aria-expanded="false" aria-controls="collapse-3">
                                        Where does it come from?
                                    </a>
                            </div>
                            <div id="collapse-3" class="collapse" data-parent="#accordion" aria-labelledby="heading-3">
                                <div class="card-body">
                                    Text 3
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="card">
                            <div class="card-header" id="heading-4">
                                <h5 class="mb-0">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapse-4"
                                        aria-expanded="false" aria-controls="collapse-4">
                                        Where does it come from?
                                    </a>
                            </div>
                            <div id="collapse-4" class="collapse" data-parent="#accordion" aria-labelledby="heading-4">
                                <div class="card-body">
                                    Text 3
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading-5">
                                <h5 class="mb-0">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapse-5"
                                        aria-expanded="false" aria-controls="collapse-5">
                                        Where does it come from?
                                    </a>
                            </div>
                            <div id="collapse-5" class="collapse" data-parent="#accordion" aria-labelledby="heading-5">
                                <div class="card-body">
                                    Text 3
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading-6">
                                <h5 class="mb-0">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapse-6"
                                        aria-expanded="false" aria-controls="collapse-6">
                                        Where does it come from?
                                    </a>
                            </div>
                            <div id="collapse-6" class="collapse" data-parent="#accordion" aria-labelledby="heading-6">
                                <div class="card-body">
                                    Text 3
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading-7">
                                <h5 class="mb-0">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapse-7"
                                        aria-expanded="false" aria-controls="collapse-7">
                                        Where does it come from?
                                    </a>
                            </div>
                            <div id="collapse-7" class="collapse" data-parent="#accordion" aria-labelledby="heading-7">
                                <div class="card-body">
                                    Text 3
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<!--Start-end-->


    <!-- My account popup Modal start -->
    <div id="account-popup" class="email-model modal fade show" role="dialog" style="display:block">
        <div class="modal-dialog email-popup-model">
            <!-- Modal content-->
            <div class="modal-content download-wrap">
                <div class="email-header">
                    Downloads  <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="account-pop-table">
                        <table class="table">
                            <thead>
                            <tr>
                                <th>Items</th>
                                <th>Description</th>
                                <th></th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td>
                                    <div class="photo-thumb"> <img src="./images/products/View-Order-without-frame.jpg" alt=""></div>
                                </td>
                                <td>
                                    <h4>Order photos-Print</h4>
                                    <span>Size 13 X 18cm</span>
                                    <span>University Logo Effects</span>
                                    <span>Reference</span>
                                </td>
                                <td>
                                    <h4>Cost</h4>
                                    <span>$45.00 inc GST</span>
                                    <span>$30.00 inc GST</span>
                                    <span>G171217LAD001</span>
                                </td>

                                <td>
                                    <button type="button" class="btn btn-primary download-btn"> <span class="download-icon"></span> Download</button>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="photo-thumb"> <img src="./images/products/View-Order-without-frame.jpg" alt=""></div>
                                </td>
                                <td>
                                    <h4>Order photos-Print</h4>
                                    <span>Size 13 X 18cm</span>
                                    <span>University Logo Effects</span>
                                    <span>Reference</span>
                                </td>
                                <td>
                                    <h4>Cost</h4>
                                    <span>$45.00 inc GST</span>
                                    <span>$30.00 inc GST</span>
                                    <span>G171217LAD001</span>
                                </td>

                                <td>
                                    <span class="not-available">Not available to<br>download</span>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="photo-thumb"> <img src="./images/products/View-Order-without-frame.jpg" alt=""></div>
                                </td>
                                <td>
                                    <h4>Order photos-Print</h4>
                                    <span>Size 13 X 18cm</span>
                                    <span>University Logo Effects</span>
                                    <span>Reference</span>
                                </td>
                                <td>
                                    <h4>Cost</h4>
                                    <span>$45.00 inc GST</span>
                                    <span>$30.00 inc GST</span>
                                    <span>G171217LAD001</span>
                                </td>

                                <td>
                                    <button type="button" class="btn btn-primary download-btn"> <span class="download-icon"></span> Download</button>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                        <div class="download-btn-wrap"> <button type="button" class="btn btn-primary normalbtn"> <span class="download-icon-white"></span> Download All</button></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- My account popup Modal start -->
<?php include 'footer.php'; ?>