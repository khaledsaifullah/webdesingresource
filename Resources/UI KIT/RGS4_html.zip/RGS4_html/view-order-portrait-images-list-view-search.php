<?php include 'header.php'; ?>
    <!--Start-body-->
    <div class="search-wrap">
        <div class="view-search">
            <h2>To view you portrait images please enter your G-code </h2>
            <form action="">
                <div class="form-group">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Enter G-code">
                        <div class="input-group-append">
                            <span class="input-group-text searchbtn">Go <i class="fi fi-arrow-thin-right goarrow"></i></span>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <!--Start-end-->
<?php include 'footer.php'; ?>