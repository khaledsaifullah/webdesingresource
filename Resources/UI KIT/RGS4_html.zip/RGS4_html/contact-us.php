<?php include 'header.php'; ?>
<!--Start-body-->
<div class="body-content">
<div class="container content-wrap">
<!-- email popup Modal start -->
    <h1 class="title-text">Contact Us </h1>
    <div class="contact-info-wrap">
       <!-- <h2>Contact Info</h2>-->
        <div class="contact-info">
            <div class="row">
                <div class="col-sm-4">
                    <div class="info">
                    <h3>Call Us</h3>
                        <p><a href="#">1300361806</a><br>
                            <a href="#"> + 61 3 9798 7199</a>
                        </p>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="info">
                        <h3>E-mail</h3>
                        <p><a href="#">contact@rgs.com</a></p>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="info bordernone">
                        <h3>Address</h3>
                        <p>29 Pacific Drive, Keysborough<br>
                            VIC,3173, Australia
                        </p>
                    </div>
                </div>
            </div>
        </div>
     <div class="contact-us-form-wrap">
        <h5>Contact Reed Graduations</h5>
        <div class="sign-up-border-box">
        <form action="">
            <div class="row">
                <div class="col-sm-6 col-xs-12">
                    <div class="form-group">
                        <label>First Name</label>
                        <input type="text" class="form-control" placeholder="John " name="firstname">
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="form-group">
                        <label>Last Name</label>
                        <input type="text" class="form-control" placeholder="Doe" name="lastname">
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="form-group">
                        <label>Email Address <span>*</span></label>
                        <input type="text" class="form-control" placeholder="John@email.com " name="email-address">
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="form-group">
                        <label>Phone </label>
                        <input type="text" class="form-control" placeholder="" name="Phone">
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="form-group">
                        <label>Reference ID</label>
                        <input type="text" class="form-control" placeholder=" " name="">
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                     <div class="form-group">
                        <label>University Name</label>
                             <select class="custom-dropdown">
                                  <option>Victoria</option>
                                  <option disabled>Select Option Two</option>
                                  <option>Select Option Two</option>
                                  <option>Select Option Three</option>
                                  <option>Select Option Four</option>
                            </select>
                       </div>

                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group">
                        <label>Meassage</label>
                        <textarea class="form-control" rows="5" placeholder="Please specify your enquiry"></textarea>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <div class="robot-box">
                         <div class="input-group">
                            <span class="custom-checkbox">
                            <input type="checkbox" id="c-10">
                            <label for="c-10">I'm not robot</label>
                            </span>
                         </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <button type="button" class="btn btn-primary normalbtn-lg w100">Submit <span class="btn-right-arrow"></span></button>
                </div>
            </div>
        </form>
      </div>
    </div>
</div>
</div>
</div>
<!-- email popup Modal end -->
<?php include 'footer.php'; ?>
