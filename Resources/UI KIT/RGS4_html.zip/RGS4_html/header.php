<!DOCTYPE html>
<html lang="en">
<head>
    <title>Reed Graduation</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="Shortcut Icon" type="image/x-icon" href="images/favicon.ico" />
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="owlcarousel/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="owlcarousel/assets/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="css/style-guide.css" />
    <link rel="stylesheet" href="css/responsive.css" />

    <script src="js/jquery-3.3.1.min.js" type="text/javascript"></script>
 

</head>
<body>

<header class="header-wrap">
    <div class="container">
        <div class="row">
            <div class="col-sm-3">
                <div class="logo">
                    <a href="/"> <img src="images/logo.png" alt="" class="logo"></a>
                </div>
            </div>
            <div class="col-sm-8">
                <nav class="navigation-wrap navbar navbar-expand-lg navbar-light">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarText">
                        <ul class="top-menu navbar-nav mr-auto">
                            <li><a href="#">Our Services</a></li>
                            <li><a href="#">Support</a></li>
                            <li><a href="#">Contact Us</a></li>
                            <li><a href="#">Login</a></li>
                          <li>
                                 <div class="dropdown myaccountdrop">
                                        <a class="dropdown-toggle" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            My Account
                                        </a>
                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                            <a class="dropdown-item" href="#">You are logged in as ann@rectzcxcz.com</a>
                                            <a class="dropdown-item" href="#">My account</a>
                                            <a class="dropdown-item" href="#">Logout</a>
                                        </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
            <div class="col-sm-1">
                <div class="shopping-card-wrap">
                    <a href="#">
                        <span class="shop-card-icon"></span>
                        <span class="qty-num">1</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</header>

