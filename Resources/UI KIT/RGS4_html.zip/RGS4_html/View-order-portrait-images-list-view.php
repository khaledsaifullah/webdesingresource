<?php include 'header.php'; ?>
    <!--Start-body-->
    <div class="full-container">
        <div class="search-image-wrap">
            <div class="view-search-image">
                <h2>To view you portrait images please enter your G-code</h2>
                <form action="">
                    <div class="form-group">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="G190515TT001">
                            <div class="input-group-append">
                                <span class="input-group-text searchbtn">Go <i class="fi fi-arrow-thin-right goarrow"></i></span>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <h4>To view photos of Rebekah, hover over the photo to see details.</h4>
        <div class="photo-gallery-container">
            <div class="photo-thumble-box photo-big">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                    <div class="icon-wrap">
                        <a href="#" class="star-icon-white"></a>
                        <a href="#" class="message-icon-white"></a>
                    </div>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/large-photo.jpg" alt=""></a></div>
            </div>
            <div class="photo-thumble-box photo-big">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                    <div class="icon-wrap">
                        <a href="#" class="star-icon"></a>
                        <a href="#" class="message-icon"></a>
                    </div>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/portrait.jpg" alt=""></a></div>
            </div>
            <div class="photo-thumble-box photo-big">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                    <div class="icon-wrap">
                        <a href="#" class="star-icon"></a>
                        <a href="#" class="message-icon"></a>
                    </div>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/group-photo.jpg" alt=""></a></div>
            </div>
            <div class="photo-thumble-box photo-big">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                    <div class="icon-wrap">
                        <a href="#" class="star-icon"></a>
                        <a href="#" class="message-icon"></a>
                    </div>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/small-photo.jpg" alt=""></a></div>
            </div>
            <div class="photo-thumble-box photo-big">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                    <div class="icon-wrap">
                        <a href="#" class="star-icon"></a>
                        <a href="#" class="message-icon"></a>
                    </div>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/single-photo.jpg" alt=""></a></div>
            </div>

            <div class="photo-thumble-box photo-big">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                    <div class="icon-wrap">
                        <a href="#" class="star-icon"></a>
                        <a href="#" class="message-icon"></a>
                    </div>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/single-photo.jpg" alt=""></a></div>
            </div>

            <div class="photo-thumble-box photo-big">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                    <div class="icon-wrap">
                        <a href="#" class="star-icon"></a>
                        <a href="#" class="message-icon"></a>
                    </div>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/large-photo.jpg" alt=""></a></div>
            </div>
            <div class="photo-thumble-box photo-big">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                    <div class="icon-wrap">
                        <a href="#" class="star-icon"></a>
                        <a href="#" class="message-icon"></a>
                    </div>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos//portrait.jpg" alt=""></a></div>
            </div>
            <div class="photo-thumble-box photo-big">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                    <div class="icon-wrap">
                        <a href="#" class="star-icon"></a>
                        <a href="#" class="message-icon"></a>
                    </div>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/group-photo.jpg" alt=""></a></div>
            </div>

            <div class="photo-thumble-box photo-big">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                    <div class="icon-wrap">
                        <a href="#" class="star-icon"></a>
                        <a href="#" class="message-icon"></a>
                    </div>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/small-photo.jpg" alt=""></a></div>
            </div>
        </div>
        <div class="share-photo-wrap">
            <div class="next-pre-wrap">
                <nav aria-label="Page navigation example">
                    <ul class="pagination">
                        <li class="page-item">
                            <a class="page-link" href="#" aria-label="Previous">
                                <span aria-hidden="true"><span class="left-arrow"></span></span>
                                <span class="sr-only">Previous</span>
                            </a>
                        </li>
                        <li class="page-item"><a class="page-link" href="#">1</a></li>
                        <li class="page-item active"><a class="page-link" href="#">2</a></li>
                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                        <li class="page-item"><a class="page-link" href="#">4</a></li>
                        <li class="page-item"><a class="page-link" href="#">5</a></li>
                        <li class="page-item"><a class="page-link" href="#">6</a></li>
                        <li class="page-item">
                            <a class="page-link" href="#" aria-label="Next">
                                <span aria-hidden="true"><span class="right-arrow"></span></span>
                                <span class="sr-only">Next</span>
                            </a>
                        </li>
                    </ul>
                </nav>
             </div>
                <h2>Share your photos with your family</h2>
                <form action="">
                    <div class="form-group">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Enter email address">
                            <div class="input-group-append">
                                <span class="input-group-text searchbtn"> Send <i class="fi fi-arrow-thin-right goarrow"></i></span>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
    </div>
    <!--Start-end-->
<?php include 'footer.php'; ?>

