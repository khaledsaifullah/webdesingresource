<?php include 'header.php'; ?>
<!--Start-body-->
<div class="body-content">
<div class="container content-wrap">
          <div class="breadcum-wrap">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Plaque</a></li>
                <li class="breadcrumb-item"><a href="#">Walnut & Gold Plaque</a></li>
            </ol>
        </div>
    <h1 class="title-text">Graduation Booking</h1>
       <div class="checkout-box">
                <div class="checkout-wrap">
                    <div class="checkout-border-box">
                        <div class="select-options accordinwrap">
                            <div id="so-accordion">
                                <div class="row no-gutters">
                                    <div class="col-sm-12">
                                        <div class="card">
                                            <div class="card-header" id="so-1">
                                                <h5 class="mb-0">
                                                    <a class="collapsed" role="button" data-toggle="collapse" href="#so-1collapse-1" aria-expanded="false" aria-controls="so-1collapse-1">
                                                      Step1: Graduand Ticket
                                                    </a>
                                                </h5>
                                            </div>
                                            <div id="so-1collapse-1" class="collapse" data-parent="#so-accordion" aria-labelledby="so-1">
                                                <div class="card-body">
                                                        <div class="row">
                                                            <div class="col-sm-6 col-md-6">
                                                                <div class="left-graduation-booking-wrap">
																  <form action="">
																		<div class="form-group">
																			<label>Formal Name: </label>
																			<input type="text" class="form-control" placeholder="John doe " name="formalname" readonly>
																		</div>
																		<div class="form-group">
																			<label>Award Title</label>
																			<input type="text" class="form-control" placeholder="Bachelor of Science" name="awardtitle" readonly>
																		</div>
																		 <div class="form-group">
																			 <label>Award Title2</label>
																			 <input type="text" class="form-control" placeholder="Bachelor of Science" name="awardtitle2" readonly>
																		</div>
																		<div class="form-group">
																			<label>Ceremony Date</label>
																			<input type="text" class="form-control" placeholder="07 jul 2019" name="ceremonydate" readonly>
																		</div>
																		<div class="form-group">
																			<label>Ceremony Time</label>
																			<input type="text" class="form-control" placeholder="11:00 AM" name="ceremonydate" readonly>
																		</div>
																	</form>
                                                                    <div class="venue-wrap">
                                                                        <span>Venue:</span>
                                                                        <p>Sydney international Convention Centre, 14 Darling Drive,<br>2009, New South Wales
																		 <a href="" style="text-decoration:underline">View on map</a>
																		</p>
                                                                       
                                                                    </div>
      
                                                                </div>
                                                            </div>

                                                            <div class="col-sm-6 col-md-6">
                                                                <div class="right-graduation-booking-wrap">
																   <div class="description-wrap">
                                                                        <span>Description</span>
                                                                        <p>Click add to cart to redirected to the payment page.After confirming your<br>details you will be emailed your Registration confirmation</p>
                                                                   </div>
																   <form action="">
																     <div class="check-billinfo">
                                                                       <h6>Please confirm that your Name and Award Title are correct</h6>
																		<div class="input-group-inline">
																			<div class="input-group">
																			<span class="custom-radio">
																				<input type="radio" id="Yes" name="YN">
																				<label for="Yes">Yes</label>
																			</span>
																				<span class="custom-radio">
																				<input type="radio" id="No" name="YN">
																				<label for="No">No</label>
																			</span>
																			</div>
																		</div>
																	  </div>
																	  <div class="form-group">
												                         <textarea class="form-control" rows="5" placeholder="Please provide correction" style="height:68px"></textarea>
                                                                      </div>
                                                                      <div class="form-group">
                                                                        <label>Pronunciation</label>
                                                                        <input type="text" class="form-control" placeholder="John " name="Pronunciation">
                                                                      </div>
                                                                 
																	 <div class="form-group">
																		 <label>Special access need</label>
																		 <select class="custom-dropdown">
																			<option>Select Option One</option>
																			<option>Select Option Two</option>
																			<option>Select Option Three</option>
																			<option>Select Option Four</option>
																		 </select>
                                                                      </div>
																	  
																	 <div class="file-upload-block single-option">
																		<label>Audio</label>
																		 <div class="file-upload">
																			<div class="file-upload-text"><span><i class="fi fi-upload"></i> Upload file</span></div>
																			<input type="file">
																		</div>
                                                                      </div>
																	</form>
                                                                </div>
																 <div class="add-to-card-doller-wrap">
                                                                        <span class="price-show">$118.00</span>
                                                                        <button type="button" class="btn btn-primary normalbtn-lg">Add to cart <span class="btn-right-arrow"></span></button>
                                                                 </div>
                                                            </div>
                                                        </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card">
                                            <div class="card-header" id="Regalia">
                                                <h5 class="mb-0">
                                                    <a class="collapsed" role="button" data-toggle="collapse" href="#so-2collapse-2" aria-expanded="false" aria-controls="so-2collapse-2">
                                                      Step2: Regalia
                                                    </a>
                                                </h5>
                                            </div>
                                            <div id="so-2collapse-2" class="collapse" data-parent="#so-accordion" aria-labelledby="Regalia">
                                                <div class="card-body">
                                                     Regalia here...
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card last" style="border-bottom: 0px!important;">
                                            <div class="card-header" id="Guesttickets">
                                                <h5 class="mb-0">
                                                    <a class="collapsed active" role="button" data-toggle="collapse" href="#so-2collapse-3" aria-expanded="false" aria-controls="so-2collapse-3">
                                                        Step3: Guest tickets
                                                    </a>
                                                </h5>
                                            </div>
                                            <div id="so-2collapse-3" class="collapse show" data-parent="#so-accordion" aria-labelledby="Guesttickets">
                                                 <div class="card-body">
                                                        <div class="row">
                                                            <div class="col-sm-6 col-md-6">
                                                                <div class="left-graduation-booking-wrap">
																  <form action="">
														                <div class="form-group">
																			<label>Ceremony Date</label>
																			<input type="text" class="form-control" placeholder="07 jul 2019" name="ceremonydate" readonly>
																		</div>
																		<div class="form-group">
																			<label>Ceremony Time</label>
																			<input type="text" class="form-control" placeholder="11:00 AM" name="ceremonydate" readonly>
																		</div>
																	</form>
                                                                    <div class="venue-wrap">
                                                                        <span>Venue:</span>
                                                                        <p>Sydney international Convention Centre, 14 Darling Drive,<br>2009, New South Wales
																		 <a href="" style="text-decoration:underline">View on map</a>
																		</p>
                                                                       
                                                                    </div>
      
                                                                </div>
                                                            </div>

                                                            <div class="col-sm-6 col-md-6">
                                                                <div class="right-graduation-booking-wrap">
																   <div class="description-wrap">
                                                                        <span>Description</span>
                                                                        <p>Click add to cart to redirected to the payment page.After confirming your<br>details you will be emailed your Registration confirmation</p>
                                                                   </div>
																   <form action="">
																     <div class="check-billinfo">
                                                                       <h6>Opt Output Option</h6>
																		<div class="input-group-inline">
																			<div class="input-group">
																			<span class="custom-radio">
																				<input type="radio" id="Yes1" name="YN">
																				<label for="Yes1">I don't need guest tickets</label>
																			</span>
																				<span class="custom-radio">
																				<input type="radio" id="No1" name="YN">
																				<label for="No1">I will come back later</label>
																			</span>
																			</div>
																		</div>
																	  </div>
																	
                                                                      <div class="form-group inc-dec">
																			<input type="text" class="form-control" placeholder="Quantity">
																			<div class="inc-dec-btn">
																				<button class="increase-qty">-</button>
																				<span>2</span>
																				<button class="increase-qty">+</button>
																			</div>
                                                                       </div>
																	</form>
                                                                </div>
																 <div class="add-to-card-doller-wrap">
                                                                        <span class="price-show">$118.00</span>
                                                                        <button type="button" class="btn btn-primary normalbtn-lg">Add to cart <span class="btn-right-arrow"></span></button>
                                                                 </div>
                                                            </div>
                                                        </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
		  <div class="freq-ask-qus">
            <h2 class="title">Frequently Asked Questions</h2>
            <div id="accordion">

                <div class="row">
                    <div class="col-sm-6">
                        <div class="card">
                            <div class="card-header" id="heading-1">
                                <h5 class="mb-0">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapse-1"
                                        aria-expanded="false" aria-controls="collapse-1">
                                        Where does it come from?
                                    </a>
                                </h5>
                            </div>
                            <div id="collapse-1" class="collapse" data-parent="#accordion" aria-labelledby="heading-1">
                                <div class="card-body">
                                    Text 1
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading-2">
                                <h5 class="mb-0">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapse-2"
                                        aria-expanded="true" aria-controls="collapse-2">
                                        What is Lorem Ipsum?
                                    </a>
                                </h5>
                            </div>
                            <div id="collapse-2" class="collapse show" data-parent="#accordion"
                                aria-labelledby="heading-2">
                                <div class="card-body">
                                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                    Ipsum has been the industry's standard dummy text ever since the 1500s.
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading-3">
                                <h5 class="mb-0">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapse-3"
                                        aria-expanded="false" aria-controls="collapse-3">
                                        Where does it come from?
                                    </a>
                            </div>
                            <div id="collapse-3" class="collapse" data-parent="#accordion" aria-labelledby="heading-3">
                                <div class="card-body">
                                    Text 3
                                </div>
                            </div>
                        </div>
                    </div>
                   <div class="col-sm-6">
                        <div class="card">
                            <div class="card-header" id="heading-4">
                                <h5 class="mb-0">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapse-4"
                                        aria-expanded="false" aria-controls="collapse-4">
                                        Where does it come from?
                                    </a>
                            </div>
                            <div id="collapse-4" class="collapse" data-parent="#accordion" aria-labelledby="heading-4">
                                <div class="card-body">
                                    Text 3
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading-5">
                                <h5 class="mb-0">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapse-5"
                                        aria-expanded="false" aria-controls="collapse-5">
                                        Where does it come from?
                                    </a>
                            </div>
                            <div id="collapse-5" class="collapse" data-parent="#accordion" aria-labelledby="heading-5">
                                <div class="card-body">
                                    Text 3
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading-6">
                                <h5 class="mb-0">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapse-6"
                                        aria-expanded="false" aria-controls="collapse-6">
                                        Where does it come from?
                                    </a>
                            </div>
                            <div id="collapse-6" class="collapse" data-parent="#accordion" aria-labelledby="heading-6">
                                <div class="card-body">
                                    Text 3
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading-7">
                                <h5 class="mb-0">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapse-7"
                                        aria-expanded="false" aria-controls="collapse-7">
                                        Where does it come from?
                                    </a>
                            </div>
                            <div id="collapse-7" class="collapse" data-parent="#accordion" aria-labelledby="heading-7">
                                <div class="card-body">
                                    Text 3
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
        </div>
    </div>
<?php include 'footer.php'; ?>
