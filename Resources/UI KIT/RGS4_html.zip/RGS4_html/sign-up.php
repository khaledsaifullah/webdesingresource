<?php include 'header.php'; ?>
<!--Start-body-->
<div class="body-content">
<div class="container content-wrap">
<!-- email popup Modal start -->
    <h1 class="title-text">Sign Up </h1>
    <div class="sign-up-wrap">
        <div class="sign-up-border-box">
        <form action="">
            <div class="row">
                <div class="col-sm-6 col-xs-12">
                    <div class="form-group">
                        <label>First Name <span>*</span></label>
                        <input type="text" class="form-control" placeholder="John " name="firstname">
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="form-group">
                        <label>Last Name <span>*</span></label>
                        <input type="text" class="form-control" placeholder=" Doe" name="firstname">
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="form-group">
                        <label>Email Address <span>*</span></label>
                        <input type="text" class="form-control" placeholder="John@email.com " name="email">
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="form-group">
                        <label>Confirm Email Address <span>*</span></label>
                        <input type="text" class="form-control" placeholder="John@email.com " name="email">
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="form-group">
                        <label>Password <span>*</span></label>
                        <input type="Password" class="form-control" placeholder=" ******" name="Password">
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="form-group">
                        <label>Confirm Password <span>*</span></label>
                        <input type="Password" class="form-control" placeholder=" ******" name="Password">
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-12">
                    <label>Phone <span>*</span></label>
                    <input type="text" class="form-control" placeholder="887 6465 65456" name="telephone">
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <button type="button" class="btn btn-primary normalbtn-lg w100">Sign Up <span class="btn-right-arrow"></span></button>
                </div>
            </div>
        </form>
    </div>
</div>
</div>
</div>
<!-- email popup Modal end -->
<?php include 'footer.php'; ?>
