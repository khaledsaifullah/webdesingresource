
    <!-- email popup Modal start -->
    <div id="email-popup" class="email-model modal fade" role="dialog">
        <div class="modal-dialog email-popup-model">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="email-header">
                    Email  <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <p>Add email address of your friends/family who you want to share the proofs with, and email will be sent once the proofs are ready.</p>
                    <h5>Recipient information</h5>
                    <form action="">
                        <div class="row">
                            <div class="col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label>Recipient’s Name</label>
                                    <input type="text" class="form-control" placeholder=" ">
                                </div>
                            </div>
                            <div class="col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label>Recipient’s Email</label>
                                    <input type="text" class="form-control" placeholder=" " name="">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <h6>Message (optional)</h6>
                                <div class="meassage-option-box">
                                    <div class="form-group">
                                        <textarea class="form-control" rows="5" placeholder="Write a message"></textarea>
                                    </div>
                                    <div class="twilight-wrap">
                                        <img src="images/twilight.png" alt="">
                                        <span>
                                        <p>Twilight</p>
                                        <p class="twi-from-text">From $695.00</p>
                                    </span>
                                    </div>
                                </div>
                                <button type="button" class="btn btn-primary submitbtn"> Send <span class="btn-right-arrow"></span> </button>
                            </div>
                        </div>
                    </form>
                </div>

            </div>

        </div>
    </div>
