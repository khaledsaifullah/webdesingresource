<?php include 'header.php'; ?>
<!--Start-body-->
<div class="body-content">
<div class="container content-wrap">
        <h1>Frame</h1>
        <div class="pro-list-view-wrap">
           <div class="item-showing-wrap">
              <div class="row">
                 <div class="col-sm-12 text-right">
                     <form action="#" method="get">
                         <span>Sort by: </span>
                         <div class="form-group selectbox">
                          <select class="custom-dropdown custom-select" style="display: none;">
                            <option>Recommended</option>
                            <option>Option Two</option>
                            <option>Option Two</option>
                          </select>
                         </div>
                     </form>
                 </div>
             </div>
           </div>
            <div class="showing-item-num">
                <span>Showing:</span> 12 of 120 items
            </div>

            <div class="pro-list-view frame-list-view">
                <div class="row">
                    <div class="col-sm-3">
                        <div class="filter-options-wrap">
                            <h3>Filter Options</h3>
                            <div class="filter-list-item">
                            <div class="item-list-title"><a href="" class="down-arrow"></a> Frame type</div>
                                <ul>
                                    <li>
                                        <div class="form-group">
                                       <span class="custom-checkbox">
                                       <input type="checkbox" id="c-4">
                                             <label for="c-4"></label>
                                       </span>
                                            <span class="single-certifi"> <img src="images/filter-icon/single-certificate.png" alt=""></span>
                                            <span> Single certificate</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="form-group">
                                       <span class="custom-checkbox">
                                       <input type="checkbox" id="c-5">
                                             <label for="c-5"></label>
                                       </span>
                                            <span class="double-certifi"> <img src="images/filter-icon/double-certificate.png" alt=""></span>
                                            <span> Double certificate</span>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="form-group">
                                       <span class="custom-checkbox">
                                       <input type="checkbox" id="c-6">
                                             <label for="c-6"></label>
                                       </span>
                                            <span class="portrait-certifie"> <img src="images/filter-icon/db-certificate.png" alt=""></span>
                                            <span> Certificate and Portrait</span>
                                        </div>
                                    </li>
                                </ul>
                         </div>
                            <div class="filter-list-item">
                                <div class="item-list-title"><a href="" class="down-arrow"></a> Frame Material</div>
                                <ul>
                                    <li>
                                        <div class="form-group">
                                       <span class="custom-checkbox">
                                       <input type="checkbox" id="c-7">
                                             <label for="c-7"></label>
                                       </span>
                                            <span class="fra-black"> <img src="images/filter-icon/fra-black.png" alt=""></span>
                                            <span>Black</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="form-group">
                                       <span class="custom-checkbox">
                                       <input type="checkbox" id="c-8">
                                             <label for="c-8"></label>
                                       </span>
                                            <span class="fra-cashew"> <img src="images/filter-icon/fra-cashew.png" alt=""></span>
                                            <span> Cashew</span>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="form-group">
                                       <span class="custom-checkbox">
                                       <input type="checkbox" id="c-9">
                                             <label for="c-9"></label>
                                        </span>
                                            <span class="fra-cashew"> <img src="images/filter-icon/fra-mocca.png" alt=""></span>
                                            <span> Mocca</span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <div class="filter-list-item">
                                <div class="item-list-title"><a href="" class="down-arrow"></a> Matt Colour</div>
                                <ul>
                                    <li>
                                        <div class="form-group">
                                       <span class="custom-checkbox">
                                       <input type="checkbox" id="c-10">
                                             <label for="c-10"></label>
                                       </span>
                                            <span class="matt-blue"> <img src="images/filter-icon/matt-blue.png" alt=""></span>
                                            <span>Blue</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="form-group">
                                       <span class="custom-checkbox">
                                       <input type="checkbox" id="c-11">
                                             <label for="c-11"></label>
                                       </span>
                                            <span class="matt-green"> <img src="images/filter-icon/matt-green.png" alt=""></span>
                                            <span> Green</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="form-group">
                                       <span class="custom-checkbox">
                                       <input type="checkbox" id="c-12">
                                             <label for="c-12"></label>
                                       </span>
                                            <span class="matt-black"> <img src="images/filter-icon/matt-black.png" alt=""></span>
                                            <span> Black</span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <div class="filter-list-item">
                                <div class="item-list-title"><a href="" class="down-arrow"></a> Create Option</div>
                                <ul>
                                    <li>
                                        <div class="form-group">
                                       <span class="custom-checkbox">
                                       <input type="checkbox" id="c-13">
                                             <label for="c-13"></label>
                                       </span>
                                            <span class="logo-gold"> <img src="images/filter-icon/logo-gold.png" alt=""></span>
                                            <span> Logo Plaque Gold</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="form-group">
                                       <span class="custom-checkbox">
                                       <input type="checkbox" id="c-14">
                                             <label for="c-14"></label>
                                       </span>
                                            <span class="logo-silver"> <img src="images/filter-icon/logo-silver.png" alt=""></span>
                                            <span> Logo Plaque Sliver</span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                       </div>
                    </div>

                    <div class="col-sm-9">
                        <div class="product-item-wrap">
                            <div class="product-item">
                                <div class="save-btn"><span class="pro-savebtn">12%</span></div>
                                <div class="product-picture"><a href="#"><img src="images/products/single-certificate.jpg" alt=""></a></div>
                                <div class="icon-wrap">
                                    <a href="#" class="star-icon"></a>
                                    <a href="#" class="message-icon" data-toggle="modal" data-target="#email-popup"></a>
                                </div>
                                <div class="product-name">
                                    Single certificate
                                    Black frame Blue Matt Logo Plaque Gold crest
                                </div>
                                <div class="price"><span><strike>$175.00</strike></span>  <span>$154.00</span></div>
                            </div>

                            <div class="product-item">
                                <div class="product-details" style="">
                                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                                    <a href="#" class="btn btn-primary addtocartbtn"> Add to Cart  </a>
                                </div>
                                <div class="product-picture"><a href="#"><img src="images/products/double-certificate.jpg" alt=""></a></div>
                                <div class="icon-wrap">
                                    <a href="#" class="star-icon-active"></a>
                                    <a href="#" class="message-icon"></a>
                                </div>
                                <div class="product-name"> Single certificate
                                    Black frame Blue Matt Logo Plaque Gold crest</div>
                                <div class="price">$35.00</div>
                            </div>

                            <div class="product-item">
                                <div class="product-details">
                                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                                    <a href="#" class="btn btn-primary addtocartbtn"> Add to Cart  </a>
                                </div>
                                <div class="product-picture"><a href="#"><img src="images/products/db-certificate.jpg" alt=""></a></div>
                                <div class="icon-wrap">
                                    <a href="#" class="star-icon-active"></a>
                                    <a href="#" class="message-icon"></a>
                                </div>
                                <div class="product-name"> Single certificate
                                    Black frame Blue Matt Logo Plaque Gold crest</div>
                                <div class="price">$35.00</div>
                            </div>

                            <div class="product-item">
                                <div class="product-details">
                                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                                    <a href="#" class="btn btn-primary addtocartbtn"> Add to Cart  </a>
                                </div>
                                <div class="product-picture"><img src="images/products/single-certificate.jpg" alt=""></div>
                                <div class="icon-wrap">
                                    <a href="#" class="star-icon"></a>
                                    <a href="#" class="message-icon"></a>
                                </div>
                                <div class="product-name"> Single certificate
                                    Black frame Blue Matt Logo Plaque Gold crest</div>
                                <div class="price">$35.00</div>
                            </div>

                            <div class="product-item">
                                <div class="product-details">
                                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                                    <a href="#" class="btn btn-primary addtocartbtn"> Add to Cart  </a>
                                </div>
                                <div class="product-picture"><img src="images/products/db-certifi.jpg" alt=""></div>
                                <div class="icon-wrap">
                                    <a href="#" class="star-icon"></a>
                                    <a href="#" class="message-icon"></a>
                                </div>
                                <div class="product-name"> Single certificate
                                    Black frame Blue Matt Logo Plaque Gold crest</div>
                                <div class="price">$35.00</div>
                            </div>

                            <div class="product-item">
                                <div class="product-details">
                                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                                    <a href="#" class="btn btn-primary addtocartbtn"> Add to Cart  </a>
                                </div>
                                <div class="save-btn"><span class="pro-savebtn">12%</span></div>
                                <div class="product-picture"><img src="images/products/double-certificate.jpg" alt=""></div>
                                <div class="icon-wrap">
                                    <a href="#" class="star-icon"></a>
                                    <a href="#" class="message-icon"></a>
                                </div>
                                <div class="product-name"> Single certificate
                                    Black frame Blue Matt Logo Plaque Gold crest</div>
                                <div class="price">$35.00</div>
                            </div>
                        </div>
                        <div class="view-more-wrap"><a href="#" class="viewmore">View more</a></div>
                      </div>
                    </div>
                 </div>
         </div>
    </div>
</div>
<!--Start-end-->


<!-- Email Modal start -->
<div id="email-popup-success" class="email-model modal fade show" role="dialog" style="display: block;">
    <div class="modal-dialog email-popup-model email-success">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="email-header">
               Email  <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <p>An email has been sent successfully to your<br>
                    specified recipient.</p>
                <div class="button-wrap">
                    <button type="button" class="btn btn-primary normalbtn"> Send another email <span class="btn-right-arrow"></span>  </button>
                    <button type="button" class="btn btn-primary closebtn">Close</button>
                </div>
            </div>

        </div>

    </div>
</div>

<!-- Email Modal end -->

<?php include 'footer.php'; ?>
