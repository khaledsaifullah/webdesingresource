<?php include 'header.php'; ?>
<!--Start-body-->
<div class="body-content">
<div class="container content-wrap">
    <h1 class="title-text">Checkout</h1>
    <div class="checkout-box">
        <div class="row">
            <div class="col-sm-8">
                <div class="checkout-wrap">
                    <div class="checkout-border-box">
                        <div class="select-options accordinwrap">
                            <div id="so-accordion">
                                <div class="row no-gutters">
                                    <div class="col-sm-12">
                                        <div class="card">
                                            <div class="card-header" id="so-1">
                                                <h5 class="mb-0">
                                                    <a class="collapsed" role="button" data-toggle="collapse" href="#so-1collapse-1" aria-expanded="false" aria-controls="so-1collapse-1">
                                                       Delivery Information
                                                    </a>
                                                </h5>
                                            </div>
                                            <div id="so-1collapse-1" class="collapse" data-parent="#so-accordion" aria-labelledby="so-1">
                                                <div class="card-body">
                                                    <form action="">
                                                        <div class="row">
                                                            <div class="col-sm-6 col-xs-12">
                                                                <div class="form-group">
                                                                    <label>Address Line 1 <span>*</span></label>
                                                                    <input type="text" class="form-control" placeholder="John " name="firstname">
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-6 col-xs-12">
                                                                <div class="form-group">
                                                                    <label>Address Line 2</label>
                                                                    <input type="text" class="form-control" placeholder=" Doe" name="firstname">
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-6 col-xs-12">
                                                                <div class="form-group">
                                                                    <label>City</label>
                                                                    <input type="text" class="form-control" placeholder="" name="email">
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-6 col-xs-12">
                                                                <div class="form-group">
                                                                    <label>Post Code <span>*</span></label>
                                                                    <input type="text" class="form-control" placeholder=" " name="postcode">
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-6 col-xs-12">
                                                                <div class="form-group">
                                                                    <label>State  <span>*</span></label>
                                                                    <select class="custom-dropdown">
                                                                        <option>Victoria</option>
                                                                        <option disabled>Disabled Option</option>
                                                                        <option>Select Option Two</option>
                                                                        <option>Select Option Three</option>
                                                                        <option>Select Option Four</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-6 col-xs-12">
                                                                <div class="form-group">
                                                                    <label>Country  <span>*</span></label>
                                                                    <select class="custom-dropdown">
                                                                        <option>Australia</option>
                                                                        <option disabled>Disabled Option</option>
                                                                        <option>Select Option Two</option>
                                                                        <option>Select Option Three</option>
                                                                        <option>Select Option Four</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-sm-12">
                                                                <button type="button" class="btn btn-primary normalbtn-lg w100">Continue <span class="btn-right-arrow"></span></button>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card">
                                            <div class="card-header" id="Billinfo">
                                                <h5 class="mb-0">
                                                    <a class="collapsed active" role="button" data-toggle="collapse" href="#so-2collapse-2" aria-expanded="false" aria-controls="so-2collapse-2">
                                                       Billing Information
                                                    </a>
                                                </h5>
                                            </div>
                                            <div id="so-2collapse-2" class="collapse show" data-parent="#so-accordion" aria-labelledby="Billinfo">
                                                <div class="card-body">
                                                    <form action="">
                                                        <div class="check-billinfo">
                                                            <h6>Is your billing address same as delivery address?</h6>
                                                            <div class="input-group-inline">
                                                                <div class="input-group">
                                                                <span class="custom-radio">
                                                                    <input type="radio" id="Yes" name="YN">
                                                                    <label for="Yes">Yes</label>
                                                                </span>
                                                                    <span class="custom-radio">
                                                                    <input type="radio" id="No" name="YN">
                                                                    <label for="No">No</label>
                                                                </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-sm-6 col-xs-12">
                                                                <div class="form-group">
                                                                    <label>Address Line 1 <span>*</span></label>
                                                                    <input type="text" class="form-control" placeholder="John " name="firstname">
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-6 col-xs-12">
                                                                <div class="form-group">
                                                                    <label>Address Line 2</label>
                                                                    <input type="text" class="form-control" placeholder=" Doe" name="firstname">
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-6 col-xs-12">
                                                                <div class="form-group">
                                                                    <label>City</label>
                                                                    <input type="text" class="form-control" placeholder="" name="email">
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-6 col-xs-12">
                                                                <div class="form-group">
                                                                    <label>Post Code <span>*</span></label>
                                                                    <input type="text" class="form-control" placeholder=" " name="postcode">
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-6 col-xs-12">
                                                                <div class="form-group">
                                                                    <label>State  <span>*</span></label>
                                                                    <select class="custom-dropdown">
                                                                        <option>Victoria</option>
                                                                        <option disabled>Disabled Option</option>
                                                                        <option>Select Option Two</option>
                                                                        <option>Select Option Three</option>
                                                                        <option>Select Option Four</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-6 col-xs-12">
                                                                <div class="form-group">
                                                                    <label>Country  <span>*</span></label>
                                                                    <select class="custom-dropdown">
                                                                        <option>Australia</option>
                                                                        <option disabled>Disabled Option</option>
                                                                        <option>Select Option Two</option>
                                                                        <option>Select Option Three</option>
                                                                        <option>Select Option Four</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="row">
                                                            <div class="col-sm-12">
                                                                <button type="button" class="btn btn-primary normalbtn-lg w100">Continue <span class="btn-right-arrow"></span></button>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card">
                                            <div class="card-header" id="shipinfo">
                                                <h5 class="mb-0">
                                                    <a class="collapsed" role="button" data-toggle="collapse" href="#so-2collapse-3" aria-expanded="false" aria-controls="so-2collapse-3">
                                                       Shipping Cost
                                                    </a>
                                                </h5>
                                            </div>
                                            <div id="so-2collapse-3" class="collapse" data-parent="#so-accordion" aria-labelledby="shipinfo">
                                                <div class="card-body">
                                                    Shipping Cost information--here
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card">
                                            <div class="card-header" id="lifegaurante">
                                                <h5 class="mb-0">
                                                    <a class="collapsed" role="button" data-toggle="collapse" href="#so-2collapse-4" aria-expanded="false" aria-controls="so-2collapse-3">
                                                       Lifetime Guarantee
                                                    </a>
                                                </h5>
                                            </div>
                                            <div id="so-2collapse-4" class="collapse" data-parent="#so-accordion" aria-labelledby="lifegaurante">
                                                <div class="card-body">
                                                    Bundle option (Optional) gose here..
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card last" style="border-bottom: 0px!important;">
                                            <div class="card-header" id="payinfo">
                                                <h5 class="mb-0">
                                                    <a class="collapsed" role="button" data-toggle="collapse" href="#so-2collapse-5" aria-expanded="false" aria-controls="so-2collapse-3">
                                                      Payment Information
                                                    </a>
                                                </h5>
                                            </div>
                                            <div id="so-2collapse-5" class="collapse" data-parent="#so-accordion" aria-labelledby="payinfo">
                                                <div class="card-body">
                                                    Bundle option (Optional) gose here..
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="checkout-wrap">
                    <div class="card-summery-border-box">
                        <h2>Cart Summery</h2>
                        <div class="cart-summery-table">
                            <table>
                                <tr>
                                    <td>Rings</td>
                                    <td>$695.00</td>
                                </tr>
                                <tr>
                                    <td>Order Photos(Print)</td>
                                    <td>$75.00</td>
                                </tr>
                                <tr>
                                    <td>Subtotal</td>
                                    <td>$770.00 inc GST</td>
                                </tr>
                                <tr>
                                    <td>Shipping Cost</td>
                                    <td>$35.00 inc GST</td>
                                </tr>
                                <tr>
                                    <td>GST</td>
                                    <td>$35.00 inc GST</td>
                                </tr>
                                <tr>
                                    <td>GST</td>
                                    <td>$73.18</td>
                                </tr>
                                <tr>
                                    <td>Order Total</td>
                                    <td>$805.00 inc GST</td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php include 'footer.php'; ?>
