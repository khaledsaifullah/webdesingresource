<?php include 'header.php'; ?>
<!--Start-body-->
<div class="body-content">

    <div class="container content-wrap">
        <div class="breadcum-wrap">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Plaque</a></li>
                <li class="breadcrumb-item"><a href="#">Walnut & Gold Plaque</a></li>
                <li class="breadcrumb-item active">My Account</li>
            </ol>
        </div>
        <h1 class="title-text">My Account</h1>
        <div class="contact-details">
            <div class="account-tap">
                <ul class="nav nav-tabs mb-3 account-info-tap">
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#new" role="tab" aria-selected="true">My orders</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#mail" role="tab" aria-selected="false">My
                            Favourites</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link  active show" data-toggle="tab" href="#activity" role="tab"
                            aria-selected="false">Contact details</a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane fade" id="new" role="tabpanel">
                        <div class="tab-no-content">No content has been added for this component</div>
                    </div>
                    <div class="tab-pane fade" id="mail" role="tabpanel">Favourites</div>
                    <div class="tab-pane fade  active show" id="activity" role="tabpanel">

                        <div class="contact-details">
                            <form action="#" method="get">
                                <div class="contact-details-form">
                                    <div class="input-set">
                                        <div class="set-title">Contact Details</div>
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <div class="form-group">
                                                    <label>First Name</label>
                                                    <input type="text" class="form-control" placeholder="John" readonly>
                                                </div>
                                            </div>
                                            <div class="col-sm-4">
                                                <div class="form-group">
                                                    <label>Last Name</label>
                                                    <input type="text" class="form-control" placeholder="Doe" readonly>
                                                </div>
                                            </div>
                                            <div class="col-sm-4">
                                                <div class="form-group">
                                                    <label>Email</label>
                                                    <input type="email" class="form-control"
                                                        placeholder="john@email.com" readonly>
                                                </div>
                                            </div>
                                            <div class="col-sm-12"> <a href="#" class="rstpss">Reset password</a></div>
                                        </div>
                                        <div class="set-title">Pronunciation</div>
                                        <div class="pronunciation">
                                            <div class="row">
                                                <div class="col-sm-1 mt-10">
                                                    <div class="form-group">
                                                        <span class="custom-checkbox">
                                                            <input type="checkbox" id="c-1">
                                                            <label for="c-1">Text</label>
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4">
                                                    <div class="form-group">
                                                        <input type="text" class="form-control"
                                                            placeholder="Enter the pronunciation">
                                                    </div>
                                                </div>
                                                <div class="col-sm-2 mt-10">
                                                    <div class="form-group text-right">
                                                        <span class="custom-checkbox">
                                                            <input type="checkbox" id="AudioFile">
                                                            <label for="AudioFile">Audio File</label>
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4">
                                                    <div class="file-upload-block single-option">
                                                        <div class="file-upload">
                                                            <div class="file-upload-text">
                                                                <span><i class="fi fi-upload"></i> Browse</span>
                                                            </div>
                                                            <input type="file">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-12">
                                            <button type="button" class="btn btn-primary submitbtn"> Submit <span class="btn-right-arrow"></span> </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--Start-end-->
<?php include 'footer.php'; ?>