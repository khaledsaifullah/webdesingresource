<?php include 'header.php'; ?>
<!--Start-body-->
<div class="body-content">

    <div class="container content-wrap">
        <div class="breadcum-wrap">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Frame</a></li>
                <li class="breadcrumb-item"><a href="#">Single Certificate</a></li>
            </ol>
        </div>
        <h1 class="title-text">Single Certificate - <span>$175.00</span> </h1>
        <div class="plaques-details-page">
            <div class="row">
                <div class="col-sm-5 col-md-12 col-lg-5">
                    <div class="reedgraduations-frame-details-slider">
                        <div id="reedgraduations-frame-details-slider">
                            <div class="item">

                                <div class="back-color blue"></div>
                                <div class="frame">
                                    <img src="./images/reedgraduations-frame/frame.png" alt="">
                                </div> 
                                <div class="product-img">
                                    <img src="./images/reedgraduations-frame/View-Order-without-frame.jpg" alt="">
                                </div>
                                <div class="logo"><img src="./images/reedgraduations-frame/logo.png" alt="LOGO"></div>
                            </div>
                        </div>
                        <div class="owl-nav">
                            <div class="customNextBtn"></div>
                            <div class="customPrevBtn"></div>
                        </div>
                        <div class="option-icons">
                            <a href="#" class="star-icon"></a>
                            <a href="#" class="message-icon"></a>
                        </div>
                        <div class="vid-bullet">
                            <ul>
                                <li><button></button></li>
                                <li><button class="active"></button></li>
                                <li><button></button></li>
                                <li><button></button></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-sm-5 col-md-12 col-lg-7">
                    <div class="product-descriptions">
                        <h4>Description</h4>
                        <p>You have earned it. Celeberate your achievement with a memorabel frame blah blah blah. Each frame is crafted in America. Our frames are tailor made to the dimensions of your diploma. Make it your own, choosing style, wood, type of glass, mat color, texture and accents.</p>
                        <h4>Specifications</h4>
                        <ul>
                            <li>Mahogany finish</li>
							<li>Beautiful suede mat</li>
							<li>Unique mahogany, gold or silver wood fillet to frame and accent</li>
							<li>Unique mahogany, gold or silver wood fillet to frame and accent the insert opening</li>
							<li>2 ½ inch moulding profile</li>
							<li>Dimensions</li>
                        </ul>
                    </div>
                    <form action=""> 
                        <div class="row">
                            <div class="col-sm-4 col-md-4 col-xs-12">
                                <div class="form-group inc-dec">
                                    <input type="text" class="form-control" placeholder="Quantity">
                                    <div class="inc-dec-btn">
                                        <button class="increase-qty">-</button>
                                        <span>2</span>
                                        <button class="increase-qty">+</button>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-8 col-md-8 col-xs-12">
                                <button type="button" class="btn btn-primary normalbtn-lg w100">Add to Cart <span
                                        class="btn-right-arrow"></span></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="frame-select-wrap">
            <h2>If you wish to explore other options, please make a selection from the options below:</h2>
            <div class="row">
                <div class="col-sm-6 col-md-3">
                    <h3>Select frame type</h3>
                    <div class="frame-border-box">
                        <div class="frame-item">
						   <input type="radio" name="frame" id="cri-single" class="input-hidden" />
							<label for="cri-single">
							  <img 
								src="./images/reedgraduations-frame/frame-cri-single.png" 
								alt="cri-single" />
							</label>
                        </div>
						
						 <div class="frame-item">
						   <input type="radio" name="frame" id="cri-double" class="input-hidden" />
							<label for="cri-double">
							  <img 
								src="./images/reedgraduations-frame/frame-cri-double.png" 
								alt="cri-double" />
							</label>
                        </div>
						
						 <div class="frame-item">
						   <input type="radio" name="frame" id="certify-double" class="input-hidden" />
							<label for="certify-double">
							  <img 
								src="./images/reedgraduations-frame/frame-cri-double.png" 
								alt="certify-double" />
							</label>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-md-3">
                    <h3>Select frame material</h3>
                    <div class="frame-border-box">
                        <div class="frame-mat-item">
						    <input type="radio" name="frame" id="frame-black" class="input-hidden" />
							<label for="frame-black">
							  <img 
								src="./images/reedgraduations-frame/frame-black.png" alt="frame-black" />
							</label>
                        </div>
						
						 <div class="frame-mat-item">
						    <input type="radio" name="frame" id="frame-red" class="input-hidden" />
							<label for="frame-red">
							  <img 
								src="./images/reedgraduations-frame/frame-red.png" alt="frame-red" />
							</label>
                        </div>
						 <div class="frame-mat-item">
						    <input type="radio" name="frame" id="frame-blackb" class="input-hidden" />
							<label for="frame-blackb">
							  <img 
								src="./images/reedgraduations-frame/frame-black.png" alt="frame-red" />
							</label>
                        </div>

                       <div class="frame-mat-item">
						    <input type="radio" name="frame" id="frame-red2" class="input-hidden" />
							<label for="frame-red2">
							  <img 
								src="./images/reedgraduations-frame/frame-red.png" alt="frame-red" />
							</label>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-md-3">
                    <h3>Select frame material</h3>
                    <div class="frame-border-box">
					   <div class="frame-mat-item">
						    <input type="radio" name="frame" id="frame-blue" class="input-hidden" />
							<label for="frame-blue">
							  <img 
								src="./images/reedgraduations-frame/frame-blue.png" alt="frame" />
							</label>
                        </div>
						
		               <div class="frame-mat-item">
						    <input type="radio" name="frame" id="frame-green" class="input-hidden" />
							<label for="frame-green">
							  <img 
								src="./images/reedgraduations-frame/frame-green.png" alt="frame" />
							</label>
                        </div>
						
						<div class="frame-mat-item">
						    <input type="radio" name="frame" id="black-frame" class="input-hidden" />
							<label for="black-frame">
							  <img 
								src="./images/reedgraduations-frame/black-frame.png" alt="frame" />
							</label>
                        </div>
						
			            <div class="frame-mat-item">
						    <input type="radio" name="frame" id="black-frameb" class="input-hidden" />
							<label for="black-frameb">
							  <img 
								src="./images/reedgraduations-frame/frame-blue.png" alt="frame" />
							</label>
                        </div>
						
                    </div>
                </div>

                <div class="col-sm-6 col-md-3">
                    <h3>Select crest</h3>
                    <div class="frame-border-box">
						<div class="frame-mat-item">
						    <input type="radio" name="frame" id="crest-frame" class="input-hidden" />
							<label for="crest-frame">
							  <img 
								src="./images/reedgraduations-frame/crest-frame.png" alt="frame" />
							</label>
                        </div>
						
						<div class="frame-mat-item">
						    <input type="radio" name="frame" id="crest-frame-yell" class="input-hidden" />
							<label for="crest-frame-yell">
							  <img 
								src="./images/reedgraduations-frame/crest-frame-yell.png" alt="frame" />
							</label>
                        </div>
						
						<div class="frame-mat-item">
						    <input type="radio" name="frame" id="crest-frameb" class="input-hidden" />
							<label for="crest-frameb">
							  <img 
								src="./images/reedgraduations-frame/crest-frame.png" alt="frame" />
							</label>
                        </div>
						
						<div class="frame-mat-item">
						    <input type="radio" name="frame" id="crest-frame-yellb" class="input-hidden" />
							<label for="crest-frame-yellb">
							  <img 
								src="./images/reedgraduations-frame/crest-frame-yell.png" alt="frame" />
							</label>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <div class="freq-ask-qus">
            <h2 class="title">Frequently Asked Questions</h2>
            <div id="accordion">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="card">
                            <div class="card-header" id="heading-1">
                                <h5 class="mb-0">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapse-1"
                                        aria-expanded="false" aria-controls="collapse-1">
                                        Where does it come from?
                                    </a>
                                </h5>
                            </div>
                            <div id="collapse-1" class="collapse" data-parent="#accordion" aria-labelledby="heading-1">
                                <div class="card-body">
                                    Text 1
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading-2">
                                <h5 class="mb-0">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapse-2"
                                        aria-expanded="true" aria-controls="collapse-2">
                                        What is Lorem Ipsum?
                                    </a>
                                </h5>
                            </div>
                            <div id="collapse-2" class="collapse show" data-parent="#accordion"
                                aria-labelledby="heading-2">
                                <div class="card-body">
                                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                    Ipsum has been the industry's standard dummy text ever since the 1500s.
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading-3">
                                <h5 class="mb-0">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapse-3"
                                        aria-expanded="false" aria-controls="collapse-3">
                                        Where does it come from?
                                    </a>
                            </div>
                            <div id="collapse-3" class="collapse" data-parent="#accordion" aria-labelledby="heading-3">
                                <div class="card-body">
                                    Text 3
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="card">
                            <div class="card-header" id="heading-4">
                                <h5 class="mb-0">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapse-4"
                                        aria-expanded="false" aria-controls="collapse-4">
                                        Where does it come from?
                                    </a>
                            </div>
                            <div id="collapse-4" class="collapse" data-parent="#accordion" aria-labelledby="heading-4">
                                <div class="card-body">
                                    Text 3
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading-5">
                                <h5 class="mb-0">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapse-5"
                                        aria-expanded="false" aria-controls="collapse-5">
                                        Where does it come from?
                                    </a>
                            </div>
                            <div id="collapse-5" class="collapse" data-parent="#accordion" aria-labelledby="heading-5">
                                <div class="card-body">
                                    Text 3
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading-6">
                                <h5 class="mb-0">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapse-6"
                                        aria-expanded="false" aria-controls="collapse-6">
                                        Where does it come from?
                                    </a>
                            </div>
                            <div id="collapse-6" class="collapse" data-parent="#accordion" aria-labelledby="heading-6">
                                <div class="card-body">
                                    Text 3
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="heading-7">
                                <h5 class="mb-0">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapse-7"
                                        aria-expanded="false" aria-controls="collapse-7">
                                        Where does it come from?
                                    </a>
                            </div>
                            <div id="collapse-7" class="collapse" data-parent="#accordion" aria-labelledby="heading-7">
                                <div class="card-body">
                                    Text 3
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<!--Start-end-->
<?php include 'footer.php'; ?>