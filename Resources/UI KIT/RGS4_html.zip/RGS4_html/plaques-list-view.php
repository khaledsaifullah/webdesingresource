<?php include 'header.php'; ?>
<!--Start-body-->
<div class="body-content">
<div class="container content-wrap">
        <h1>Plaque</h1>
        <div class="pro-list-view-wrap">
           <div class="item-showing-wrap">
              <div class="row">
                 <div class="col-sm-12 text-right">
                     <form action="#" method="get">
                         <span>Sort by: </span>
                         <div class="form-group selectbox">
                          <select class="custom-dropdown custom-select" style="display: none;">
                            <option>Recommended</option>
                            <option>Option Two</option>
                            <option>Option Two</option>
                          </select>
                         </div>
                     </form>
                 </div>
             </div>
           </div>
            <div class="showing-item-num">
                <span>Showing:</span> 12 of 120 items
            </div>

            <div class="pro-list-view">
                <div class="product-item">
                    <div class="product-picture"><a href="#"><img src="images/products/product-img.jpg" alt=""></a></div>
                    <div class="icon-wrap">
                        <a href="#" class="star-icon"></a>
                        <a href="#" class="message-icon"></a>
                    </div>
                    <div class="product-name">Walnut & Gold Plaque</div>
                    <div class="price">$35.00</div>
                </div>
                <div class="product-item">
                    <div class="product-picture"><a href="#"><img src="images/products/product-img.jpg" alt=""></a></div>
                    <div class="icon-wrap">
                        <a href="#" class="star-icon-active"></a>
                        <a href="#" class="message-icon"></a>
                    </div>
                    <div class="product-name">Walnut & Gold Plaque</div>
                    <div class="price">$35.00</div>
                </div>

                <div class="product-item">
                    <div class="product-details" style="">
                        <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                    </div>
                    <div class="product-picture"><img src="images/products/product-photo.jpg" alt=""></div>
                    <div class="icon-wrap">
                        <a href="#" class="star-icon"></a>
                        <a href="#" class="message-icon"></a>
                    </div>
                    <div class="product-name">Walnut & Gold Plaque</div>
                    <div class="price">$35.00</div>
                </div>
                <div class="product-item">
                    <div class="product-details" style="">
                        <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                    </div>
                    <div class="product-picture"><img src="images/products/product-img.jpg" alt=""></div>
                    <div class="icon-wrap">
                        <a href="#" class="star-icon"></a>
                        <a href="#" class="message-icon"></a>
                    </div>
                    <div class="product-name">Walnut & Gold Plaque</div>
                    <div class="price">$35.00</div>
                </div>

                <div class="product-item">
                    <div class="product-details" style="">
                        <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                    </div>
                    <div class="product-picture"><img src="images/products/product-img.jpg" alt=""></div>
                    <div class="icon-wrap">
                        <a href="#" class="star-icon"></a>
                        <a href="#" class="message-icon"></a>
                    </div>
                    <div class="product-name">Walnut & Gold Plaque</div>
                    <div class="price">$35.00</div>
                </div>
                <div class="product-item">
                    <div class="product-details" style="">
                        <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                    </div>
                    <div class="product-picture"><img src="images/products/product-photo.jpg" alt=""></div>
                    <div class="icon-wrap">
                        <a href="#" class="star-icon"></a>
                        <a href="#" class="message-icon"></a>
                    </div>
                    <div class="product-name">Walnut & Gold Plaque</div>
                    <div class="price">$35.00</div>
                </div>
                <div class="product-item">
                    <div class="product-details" style="">
                        <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                    </div>
                    <div class="product-picture"><img src="images/products/product-photo.jpg" alt=""></div>
                    <div class="icon-wrap">
                        <a href="#" class="star-icon"></a>
                        <a href="#" class="message-icon"></a>
                    </div>
                    <div class="product-name">Walnut & Gold Plaque</div>
                    <div class="price">$35.00</div>
                </div>
                <div class="product-item">
                    <div class="product-details" style="">
                        <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                    </div>
                    <div class="product-picture"><img src="images/products/product-img.jpg" alt=""></div>
                    <div class="icon-wrap">
                        <a href="#" class="star-icon"></a>
                        <a href="#" class="message-icon"></a>
                    </div>
                    <div class="product-name">Walnut & Gold Plaque</div>
                    <div class="price">$35.00</div>
                </div>

                <div class="product-item">
                    <div class="product-details" style="">
                        <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                    </div>
                    <div class="product-picture"><img src="images/products/product-img.jpg" alt=""></div>
                    <div class="icon-wrap">
                        <a href="#" class="star-icon"></a>
                        <a href="#" class="message-icon"></a>
                    </div>
                    <div class="product-name">Walnut & Gold Plaque</div>
                    <div class="price">$35.00</div>
                </div>
                <div class="product-item">
                    <div class="product-details" style="">
                        <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                    </div>
                    <div class="product-picture"><img src="images/products/product-photo.jpg" alt=""></div>
                    <div class="icon-wrap">
                        <a href="#" class="star-icon"></a>
                        <a href="#" class="message-icon"></a>
                    </div>
                    <div class="product-name">Walnut & Gold Plaque</div>
                    <div class="price">$35.00</div>
                </div>
                <div class="product-item">
                    <div class="product-details" style="">
                        <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                    </div>
                    <div class="product-picture"><img src="images/products/product-photo.jpg" alt=""></div>
                    <div class="icon-wrap">
                        <a href="#" class="star-icon"></a>
                        <a href="#" class="message-icon"></a>
                    </div>
                    <div class="product-name">Walnut & Gold Plaque</div>
                    <div class="price">$35.00</div>
                </div>
                <div class="product-item">
                    <div class="product-details" style="">
                        <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                    </div>
                    <div class="product-picture"><img src="images/products/product-img.jpg" alt=""></div>
                    <div class="icon-wrap">
                        <a href="#" class="star-icon"></a>
                        <a href="#" class="message-icon"></a>
                    </div>
                    <div class="product-name">Walnut & Gold Plaque</div>
                    <div class="price">$35.00</div>
                </div>
            </div>
            <div class="view-more-wrap"><a href="#" class="viewmore">View more</a></div>
         </div>
    </div>
</div>
<!--Start-end-->
<?php include 'footer.php'; ?>
