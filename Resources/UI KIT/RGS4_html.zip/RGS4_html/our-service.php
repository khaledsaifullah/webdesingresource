<?php include 'header.php'; ?>
<!--Start-body-->
<div id="content" class="webalive-site-content">
    <div class="page-header">
        <img src="images/page-header.jpg" alt="Header Image">
        <div class="page-header-content">
            <h2>Our Services</h2>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
        </div>
    </div>

    <section class="graduating-ourservice-section margintop">
        <div class="container contentwrap">
            <div class="convocation-content">
                <div class="convocation-item">
                    <div class="convocation-student-details">
                        <h4>Studio Portraits</h4>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
                        <a href="#" class="convocation-student-detail-link"></a>
                    </div>
                    <div class="convocation-picture"><img src="images/our-services/rmit.png" alt="latrobe"></div>
                    <div class="convocation-caption">Graduation</div>
                </div>
                <div class="convocation-item">
                    <div class="convocation-student-absense"><img src="images/our-services/graduate-absense.png" alt="latrobe"></div>
                    <div class="convocation-picture"><img src="images/our-services/studio.png" alt="studio"></div>
                    <div class="convocation-caption">efer or graduate<br>in absentia</div>
                </div>
                <div class="convocation-item">
                    <div class="convocation-student-details">
                        <h4>Studio Portraits</h4>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
                        <a href="#" class="convocation-student-detail-link"></a>
                    </div>
                    <div class="convocation-picture"><img src="images/our-services/studio.png" alt="studio"></div>
                    <div class="convocation-caption">Studio Portraits</div>
                </div>
                <div class="convocation-item">
                    <div class="convocation-picture" id="convocation-load-video">
                        <a href="javascript:void(0)" class="convocation-play-btn"></a>
                        <img src="images/our-services/stage-videos.png" alt="stage-videos" data-youtube-link="https://www.youtube.com/embed/F9hUGMO7N-8?rel=0&amp;showinfo=0&amp;autoplay=1">
                    </div>
                    <div class="convocation-caption">Stage Videos</div>
                </div>
                <div class="convocation-item">
                    <div class="convocation-student-details">
                        <h4>Studio Portraits</h4>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
                        <a href="#" class="convocation-student-detail-link"></a>
                    </div>
                    <div class="convocation-picture"><img src="images/our-services/stage-photos.png" alt="stage-photos"></div>
                    <div class="convocation-caption">Stage Photos</div>
                </div>
                <div class="convocation-item">
                    <div class="convocation-student-details">
                        <h4>Studio Portraits</h4>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
                        <a href="#" class="convocation-student-detail-link"></a>
                    </div>
                    <div class="convocation-picture"><img src="images/our-services/plaques.png" alt="plaques"></div>
                    <div class="convocation-caption">Plaques</div>
                </div>
                <div class="convocation-item">
                    <div class="convocation-student-details">
                        <h4>Studio Portraits</h4>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
                        <a href="#" class="convocation-student-detail-link"></a>
                    </div>
                    <div class="convocation-picture"><img src="images/our-services/frames.png" alt="frames"></div>
                    <div class="convocation-caption">Frames</div>
                </div>
                <div class="convocation-item">
                    <div class="convocation-student-details">
                        <h4>Studio Portraits</h4>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
                        <a href="#" class="convocation-student-detail-link"></a>
                    </div>
                    <div class="convocation-picture"><img src="images/our-services/bears.png" alt="studio"></div>
                    <div class="convocation-caption">Bears</div>
                </div>
                <div class="convocation-item">
                    <div class="convocation-student-details">
                        <h4>Studio Portraits</h4>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
                        <a href="#" class="convocation-student-detail-link"></a>
                    </div>
                    <div class="convocation-picture"><img src="images/our-services/flowers.png" alt="flowers"></div>
                    <div class="convocation-caption">Flowers</div>
                </div>
                <div class="convocation-item">
                    <div class="convocation-student-details">
                        <h4>Studio Portraits</h4>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
                        <a href="#" class="convocation-student-detail-link"></a>
                    </div>
                    <div class="convocation-picture"><img src="images/our-services/rings.png" alt="rings"></div>
                    <div class="convocation-caption">Rings</div>
                </div>

            </div>
        </div>
    </section>

</div>
<?php include 'footer.php'; ?>
