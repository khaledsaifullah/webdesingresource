<?php include 'header.php'; ?>
    <!--Start-body-->
    <div class="full-container">
        <div class="search-image-wrap">
            <div class="view-search-image">
                <h2>To view you stage images please select ceremony date and time</h2>
                <form action="">
                    <div class="form-group">
                        <div class="date-time-picker date-time-normal">
                            <input type="text" class="form-control" placeholder="dd/mm/yyyy and Time"/>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <h4>To view photos of Rebekah, hover over the photo.</h4>
        <div class="photo-gallery-container">
            <div class="photo-thumble-box">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/large-photo.jpg" alt=""></a></div>
            </div>
            <div class="photo-thumble-box">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/portrait.jpg" alt=""></a></div>
            </div>
            <div class="photo-thumble-box">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/group-photo.jpg" alt=""></a></div>
            </div>
            <div class="photo-thumble-box">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/small-photo.jpg" alt=""></a></div>
            </div>
            <div class="photo-thumble-box">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/single-photo.jpg" alt=""></a></div>
            </div>
            <div class="photo-thumble-box">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/large-photo.jpg" alt=""></a></div>
            </div>
            <div class="photo-thumble-box">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/small-photo.jpg" alt=""></a></div>
            </div>
            <div class="photo-thumble-box">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/small-photo.jpg" alt=""></a></div>
            </div>



            <div class="photo-thumble-box">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/large-photo.jpg" alt=""></a></div>
            </div>
            <div class="photo-thumble-box">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/convocation-single-photo.jpg" alt=""></a></div>
            </div>
            <div class="photo-thumble-box">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/large-photo.jpg" alt=""></a></div>
            </div>
            <div class="photo-thumble-box">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/single-photo.jpg" alt=""></a></div>
            </div>
            <div class="photo-thumble-box">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/convocation-single-photo.jpg" alt=""></a></div>
            </div>
            <div class="photo-thumble-box">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/group-photo.jpg" alt=""></a></div>
            </div>

            <div class="photo-thumble-box">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/large-photo.jpg" alt=""></a></div>
            </div>



            <div class="photo-thumble-box">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/group-photo.jpg" alt=""></a></div>
            </div>

            <div class="photo-thumble-box">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/large-photo.jpg" alt=""></a></div>
            </div>

            <div class="photo-thumble-box">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/convocation-single-photo.jpg" alt=""></a></div>
            </div>
            <div class="photo-thumble-box">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/convocation-single-photo.jpg" alt=""></a></div>
            </div> <div class="photo-thumble-box">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/convocation-single-photo.jpg" alt=""></a></div>
            </div>
            <div class="photo-thumble-box">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/single-photo.jpg" alt=""></a></div>
            </div>


            <div class="photo-thumble-box">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/convocation-single-photo.jpg" alt=""></a></div>
            </div>
            <div class="photo-thumble-box">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/group-photo.jpg" alt=""></a></div>
            </div>
            <div class="photo-thumble-box">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/convocation-single-photo.jpg" alt=""></a></div>
            </div>
            <div class="photo-thumble-box">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/group-photo.jpg" alt=""></a></div>
            </div>
            <div class="photo-thumble-box">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/large-photo.jpg" alt=""></a></div>
            </div>

            <div class="photo-thumble-box">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/convocation-single-photo.jpg" alt=""></a></div>
            </div>
            <div class="photo-thumble-box">
                <div class="photo-details">
                    <a href="#" class="btn btn-primary border-btn viewbtn">View Details</a>
                </div>
                <div class="gallery-pic-image"><a href="#"><img src="images/gallery/photos/single-photo.jpg" alt=""></a></div>
            </div>


        </div>
    </div>
    <!--Start-end-->
<?php include 'footer.php'; ?>

