<?php include 'header.php'; ?>
<!--Start-body-->
<div id="content" class="webalive-site-content">
    <div class="page-header">
        <img src="images/page-header.jpg" alt="Header Image">
        <div class="page-header-content">
            <h2>University</h2>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
        </div>
    </div>

    <section class="individual-section">
        <div class="container contentwrap">
            <h2>Please specify, are you a student who is: </h2>
            <div class="row">
                <div class="col-md-6">
                    <a href="#">
                        <div class="left-graduating-now">
                            <h3>Graduating Now</h3>
                            <span class="right-arrow-ind"></span>
                        </div>
                    </a>
                </div>

                <div class="col-md-6">
                    <a href="#">
                        <div class="right-already-graduated">
                            <h3>Already Graduated</h3>
                            <span class="right-arrow-ind"></span>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </section>

    <section class="what-student-say">
        <div class="container contentwrap">
            <div class="row">
                <div class="col-md-3"><h2>What<br>Students Say<br>About Us</h2></div>
                <div class="col-md-9">
                    <div class="student-testimonial">
                        <ul>
                            <li>
                                <div class="testimonial-content">
                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type </p>
                                    <h4>Professor Dumbledore</h4>
                                    <h5>RMIT University</h5>
                                </div>
                            </li>
                            <li>
                                <div class="testimonial-content">
                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type </p>
                                    <h4>Professor Dumbledore</h4>
                                    <h5>RMIT University</h5>
                                </div>
                            </li>
                        </ul>
                        <div class="bx-controls-direction"><a class="bx-prev" href="">Prev</a><a class="bx-next" href="">Next</a></div>
                        <div class="slider-bullet-control">
                            <div class="bx-pager-item"><a href="javascript:void(0)" class="bx-pager-link"></a></div>
                            <div class="bx-pager-item"><a href="javascript:void(0)" class="bx-pager-link"></a></div>
                            <div class="bx-pager-item"><a href="javascript:void(0)" class="bx-pager-link"></a></div>
                            <div class="bx-pager-item"><a href="javascript:void(0)" class="bx-pager-link active"></a></div>
                            <div class="bx-pager-item"><a href="javascript:void(0)" class="bx-pager-link"></a></div>
                            <div class="bx-pager-item"><a href="javascript:void(0)" class="bx-pager-link"></a></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

</div>
<?php include 'footer.php'; ?>
