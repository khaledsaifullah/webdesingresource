<?php include 'header.php'; ?>
<!--Start-body-->
<div class="body-content">

    <div class="container content-wrap">
        <div class="breadcum-wrap">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Plaque</a></li>
                <li class="breadcrumb-item"><a href="#">Walnut & Gold Plaque</a></li>
                <li class="breadcrumb-item active">My Account</li>
            </ol>
        </div>
        <h1 class="title-text">My Account</h1>
        <div class="contact-details">
            <div class="account-tap">
                <ul class="nav nav-tabs mb-3 account-info-tap">
                    <li class="nav-item">
                        <a class="nav-link active show" data-toggle="tab" href="#my-orders" role="tab" aria-selected="true">My orders</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#my-favourites" role="tab"
                            aria-selected="false">My
                            Favourites</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#activity" role="tab" aria-selected="false">Contact
                            details</a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane active show" id="my-orders" role="tabpanel">
                        <div class="my-favourites">
                            <div class="fav-table orderdetails">
                                <table class="table">
                                    <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>No.</th>
                                        <th>Ship to</th>
                                        <th>Status</th>
                                        <th>Total</th>
                                        <th>Download<br>
                                            invoice</th>
                                        <th>Download image<br>
                                            and videos</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td><span>16/05/2019</span></td>
                                        <td>
                                            <span>#170778</span>
                                        </td>
                                        <td>
                                            <span>Rid Wilson</span>
                                        </td>
                                        <td><span>Processing</span></td>
                                        <td>
                                            <span>$105.00</span>
                                        </td>
                                        <td><a href="#" class="invoice-icon"></a></td>
                                        <td>
                                            <button type="button" class="btn btn-primary download-btn"> <span class="download-icon"></span> Download</button>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td><span>16/05/2019</span></td>
                                        <td>
                                            <span>#170778</span>
                                        </td>
                                        <td>
                                            <span>Rid Wilson</span>
                                        </td>
                                        <td><span>Processing</span></td>
                                        <td>
                                            <span>$105.00</span>
                                        </td>
                                        <td><a href="#" class="invoice-icon"></a></td>
                                        <td>
                                            <button type="button" class="btn btn-primary download-btn"> <span class="download-icon"></span> Download</button>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td><span>16/05/2019</span></td>
                                        <td>
                                            <span>#170778</span>
                                        </td>
                                        <td>
                                            <span>Rid Wilson</span>
                                        </td>
                                        <td><span>Processing</span></td>
                                        <td>
                                            <span>$105.00</span>
                                        </td>
                                        <td><a href="#" class="invoice-icon"></a></td>
                                        <td>
                                            <button type="button" class="btn btn-primary download-btn"> <span class="download-icon"></span> Download</button>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="my-favourites" role="tabpanel">
                        <div class="my-favourites">
                            <div class="fav-table">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>SL. No.</th>
                                            <th>Image</th>
                                            <th>Name</th>
                                            <th>Price</th>
                                            <th>Quantity</th>
                                            <th>Buying Options</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td>
                                                <div class="product-thumb"> <img src="./images/products/fav-product.png"
                                                        alt=""> </div>
                                            </td>
                                            <td>
                                                <span>Frames</span>
                                                <span>(single Certificate)</span>
                                            </td>
                                            <td>$175.00</td>
                                            <td>
                                                <div class="qty">
                                                    <button class="increase-qty">-</button>
                                                    <span>2</span>
                                                    <button class="increase-qty">+</button>
                                                </div>
                                            </td>
                                            <td>
                                                <button type="button" class="btn btn-primary submitbtn"> Add to Cart
                                                </button>
                                            </td>
                                            <td><i class="close-icon"></i></td>
                                        </tr>
                                        <tr>
                                            <td>2</td>
                                            <td>
                                                <div class="product-thumb"> <img src="./images/products/ring-product.png"
                                                        alt=""> </div>
                                            </td>
                                            <td>
                                                <span>Ring</span>
                                                <span>14k Gold</span>
                                            </td>
                                            <td>$175.00</td>
                                            <td>
                                                <div class="qty">
                                                    <button class="increase-qty">-</button>
                                                    <span>2</span>
                                                    <button class="increase-qty">+</button>
                                                </div>
                                            </td>
                                            <td>
                                            <button type="button" class="btn btn-primary closebtn">View Details</button>
                                            </td>
                                            <td><i class="close-icon"></i></td>
                                        </tr>
                                        <tr>
                                            <td>3</td>
                                            <td>
                                                <div class="product-thumb"> <img src="images/products/product-img.jpg"
                                                                                 alt=""> </div>
                                            </td>
                                            <td>
                                                <span>Frames</span>
                                                <span>(single Certificate)</span>
                                            </td>
                                            <td>$175.00</td>
                                            <td>
                                                <div class="qty">
                                                    <button class="increase-qty">-</button>
                                                    <span>2</span>
                                                    <button class="increase-qty">+</button>
                                                </div>
                                            </td>
                                            <td>
                                                <button type="button" class="btn btn-primary closebtn">View Details</button>
                                            </td>
                                            <td><i class="close-icon"></i></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="share-fav">
                                <div class="row">
                                    <div class="col-md-6">
                                        <h5>Share favourite list with friends and family</h5>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="Enter email address*">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="activity" role="tabpanel">
                        <div class="contact-details">
                            <form action="">
                                <div class="contact-details-form">
                                    <div class="input-set">
                                        <div class="set-title">Contact Details</div>
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <div class="form-group">
                                                    <label>First Name</label>
                                                    <input type="text" class="form-control" placeholder="John" readonly>
                                                </div>
                                            </div>
                                            <div class="col-sm-4">
                                                <div class="form-group">
                                                    <label>Last Name</label>
                                                    <input type="text" class="form-control" placeholder="Doe" readonly>
                                                </div>
                                            </div>
                                            <div class="col-sm-4">
                                                <div class="form-group">
                                                    <label>Email</label>
                                                    <input type="email" class="form-control"
                                                        placeholder="john@email.com" readonly>
                                                </div>
                                            </div>
                                            <div class="col-sm-12"> <a href="#" class="rstpss">Reset password</a></div>
                                        </div>
                                        <div class="set-title">Pronunciation</div>
                                        <div class="pronunciation">
                                            <div class="row">
                                                <div class="col-sm-1 mt-10">
                                                    <div class="form-group">
                                                        <span class="custom-checkbox">
                                                            <input type="checkbox" id="c-1">
                                                            <label for="c-1">Text</label>
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4">
                                                    <div class="form-group">
                                                        <input type="text" class="form-control"
                                                            placeholder="Enter the pronunciation">
                                                    </div>
                                                </div>
                                                <div class="col-sm-2 mt-10">
                                                    <div class="form-group text-right">
                                                        <span class="custom-checkbox">
                                                            <input type="checkbox" id="AudioFile">
                                                            <label for="AudioFile">Audio File</label>
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4">
                                                    <div class="file-upload-block single-option">
                                                        <div class="file-upload">
                                                            <div class="file-upload-text">
                                                                <span><i class="fi fi-upload"></i> Browse</span>
                                                            </div>
                                                            <input type="file">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <button type="button" class="btn btn-primary submitbtn"> Submit <span
                                                        class="btn-right-arrow"></span> </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--Start-end-->
<?php include 'footer.php'; ?>