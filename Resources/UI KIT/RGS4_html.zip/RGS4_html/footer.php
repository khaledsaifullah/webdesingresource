<footer class="footer-wrap">
    <div class="container">
        <div class="row">
            <div class="col-sm-5">
                <a href="#"> <img src="images/logo-footer.png" alt="" class="logo-footer"></a>
            </div>
            <div class="col-sm-4">
                <div class="textwidget read-gra-wrap">
                    <h3>Reed Graduation Services</h3>
                    <p>29 Pacific Drive<br>
                        Keysborough, VIC 3173<br>
                        Australia</p>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="textwidget"><h3>Get in Touch</h3>
                    <p>Australia: <a href="tel:1300 361 806">1300 361 806</a><br>
                        International: <a href="tel:613 9798 7199">+613 9798 7199</a><br>
                        Email: <a href="mailto:hello@reedgraduations.com.au">hello@reedgraduations.com.au</a></p>
                </div>
            </div>
        </div>
        <div class="divided-border">
            <p>© 2019 Reed Graduation Services Pty Ltd· ABN 94 604 878 293 | Website by <a href="https://www.webalive.com.au/" target="_blank" rel="noopener noreferrer">WebAlive</a></p>
        </div>
        <div class="row">
            <ul class="footer-list">
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">Security Capabilities</a></li>
                <li><a href="#"> Refund Policy</a></li>
                <li><a href="#">Employment</a></li>
            </ul>
        </div>
        <div class="back-to-top"><a href="javascript:void(0)" id="scroll-top">Up</a> </div>
    </div>
</footer>

    <script src="owlcarousel/owl.carousel.min.js"></script>
    <script src="js/popper-1.12.9.min.js" type="text/javascript"></script>
    <script src="js/bootstrap-4.min.js" type="text/javascript"></script> 
    <script src="js/moment.min.js" type="text/javascript"></script>
    <script src="js/tempusdominus-bootstrap-4.min.js" type="text/javascript"></script>
    <script src="js/chosen.jquery.min.js" type="text/javascript"></script>
    <script src="js/perfect-scrollbar.js" type="text/javascript"></script>
    <script src="js/custom.js" type="text/javascript"></script>
</body>
</html>