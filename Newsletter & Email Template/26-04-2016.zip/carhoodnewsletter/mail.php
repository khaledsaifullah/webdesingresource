<?php
	$to = 'webalive.srv@gmail.com,khaled@bitmascot.com,webalive.srv@yahoo.com,pmake552@gmail.com,faruk@bitmascot.com';
	
 	
	$subject = 'Welcome Carhood';
	
	
$html = <<<EOD



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>invoice</title>
<style>
    *{
		margin:0;
		padding:0;
	}
</style>
</head>
<body style="background-color:#f6f6f6;">
<table align="center" cellpadding="0" cellspacing="0" width="100%" bgcolor="#f6f6f6">
<tr><td align="center" valign="top" height="40"></td></tr>
<tr>
<td align="center" valign="top">
    <table align="center" cellpadding="0" cellspacing="0" width="750"  bgcolor="#FFFFFF">
        <tr><td colspan="3" height="40"></td></tr>
        <tr>
            <td width="40"></td>
            <td align="center" valign="top">
                <table align="center" cellpadding="0" cellspacing="0" width="100%">
                    <tr><td align="left" valign="top" style="color: rgba(0,0,0,0.9);font-size: 18px;font-family:Arial, Helvetica, sans-serif;">
                    <strong>PEOPLESMOVE PTY. LTD</strong></td></tr>
                </table>
    
                <table align="center" cellpadding="0" cellspacing="0" width="100%">
                    <tr>
                        <td align="left" valign="middle" width="70%">
                            <p style="color: rgba(0,0,0,0.9);cursor:pointer;font-size: 14px;font-weight: bold;font-family:Arial, Helvetica, sans-serif;"><a href="https://www.carhood.com.au/" target="_blank" style="color:rgba(0,0,0,0.9); text-decoration:none;font-family:Arial, Helvetica, sans-serif;">https://www.carhood.com.au/</a><br />ABN: 57 169499 978</p>
                        </td>
                        <td align="left" valign="top" width="30%"><img src="http://larry.webmascot.com/carhoodnewsletter/company-logo.png" alt="logo"  /></td>
                    </tr>
                    <tr><td align="left" valign="top" colspan="2" style="color: #2774bb;font-size: 28px;font-family:Arial, Helvetica, sans-serif;">
                    Tax Invoice</td></tr>
                    
                    <tr><td align="left" valign="top" height="30" colspan="2"></td></tr>
    
                    <tr>
                        <td align="left" valign="top" width="50%">
                        <table align="center" cellpadding="0" cellspacing="0" width="100%" > 
                                <tr><td align="left" style="color: rgba(0,0,0,0.9);font-size: 18px;font-family:Arial, Helvetica, sans-serif;">
                                <strong>INVOICE TO.</strong></td></tr>
                                <tr><td align="left" style="color: rgba(0,0,0,0.9);font-size: 14px;font-family:Arial, Helvetica, sans-serif;">
                                <strong>Steven Johnson</strong></td></tr>
                              </table>
                            
                        </td>
                        <td align="right" valign="top" width="50%" >
                        <table align="center" cellpadding="0" cellspacing="0" width="100%" > 
                                <tr><td align="right" style="color: rgba(0,0,0,0.9);font-size: 18px;font-family:Arial, Helvetica, sans-serif;">
                                <strong>INVOICE NO.</strong> <span>1058</span></td></tr>
                                <tr><td align="right" style="color: rgba(0,0,0,0.9);font-size: 14px;font-family:Arial, Helvetica, sans-serif;">
                                <strong>DATE</strong>. <strong>25/08/2016</strong></td></tr>
                              </table>
                        </td>
                    </tr>
                    <tr><td align="left" valign="top" colspan="2" height="40"></td></tr>
                    <tr><td align="left" valign="top" colspan="2"> <hr size="1" width="100%" align="center" /></td></tr>
                    <tr><td align="left" valign="top" colspan="2" height="70"></td></tr>
               </table>
            </td>
            <td width="40"></td>
        </tr>
        
     <tr>
            <td width="40" bgcolor="#d2dde6">&nbsp;</td>
            <td><table align="center" cellpadding="0" cellspacing="0" width="100%" bgcolor="#d2dde6"> 
                <thead>
                    <tr>
                        <th align="left" valign="middle" width="40%" height="25" style="color: #2774bb;font-size: 14px;font-family:Arial, Helvetica, sans-serif;text-transform:uppercase;"><strong>Activity</strong></th>
                        <th align="center" valign="middle" width="20%" height="25"  style="color: #2774bb;font-size: 14px;font-family:Arial, Helvetica, sans-serif;text-transform:uppercase;"><strong>Qty</strong></th>
                        <th align="center" valign="middle" width="20%" height="25"  style="color: #2774bb;font-size: 14px;font-family:Arial, Helvetica, sans-serif;text-transform:uppercase;"><strong>Rate</strong></th>
                        <th align="center" valign="middle" width="20%" height="25"  style="color: #2774bb;font-size: 14px;font-family:Arial, Helvetica, sans-serif;text-transform:uppercase;"><strong>Amount</strong></th>
                    </tr>
                </thead>
                </table></td>
            <td width="40" bgcolor="#d2dde6">&nbsp;</td>
        </tr>
        
        
        
        <tr>
        	<td width="40"></td>
            <td valign="top" align="center">
            		                
               <table align="center" cellpadding="0" cellspacing="0" width="100%" > 
                    <tbody>
                        <tr>
                            <td align="left" valign="top" width="40%">
                            	<table align="center" cellpadding="0" cellspacing="0" width="100%" > 
                                	<tr><td align="left" style="color: rgba(0,0,0,0.9);font-size: 17px;font-family:Arial, Helvetica, sans-serif;">
                                    <strong>Car Rental</strong></td></tr>
                                	<tr><td align="left" style="color: rgba(0,0,0,0.9);font-size: 14px;font-family:Arial, Helvetica, sans-serif;">
                                    <strong>Number of Days:</strong> <strong>7</strong></td></tr>
                                	<tr><td align="left" style="color: rgba(0,0,0,0.9);font-size: 14px;font-family:Arial, Helvetica, sans-serif;">
                                    <strong>Pick-up:</strong> <strong>05/09/2016</strong> <strong>07:00 am</strong></td></tr>
                                	<tr><td align="left" style="color: rgba(0,0,0,0.9);font-size: 14px;font-family:Arial, Helvetica, sans-serif;">
                                    <strong>Drop-off:</strong> <strong>12/09/2016</strong> <strong>07:00 am</strong></td></tr>
                                </table>
                            </td>
                            <td align="center" valign="top" width="20%" style="color: rgba(0,0,0,0.9);font-size: 14px;font-family:Arial, Helvetica, sans-serif;"><strong>1</strong></td>
                            <td align="center" valign="top" width="20%" style="color: rgba(0,0,0,0.9);font-size: 14px;font-family:Arial, Helvetica, sans-serif;"><strong>100.00</strong></td>
                            <td align="center" valign="top" width="20%" style="color: rgba(0,0,0,0.9);font-size: 14px;font-family:Arial, Helvetica, sans-serif;"><strong>100.00 <span style="font-size:13px;">Inc GST</span></strong></td>
                        </tr>
                        
                        <tr><td colspan="4"  height="30"></td></tr>
                        <tr><td align="left" valign="top" colspan="4" > 
                        <hr size="1" width="100%" align="center" style="border-top:1px dashed rgba(0,0,0,0.9)" /></td></tr>
                        <tr><td colspan="4"  height="30"></td></tr>
                    </tbody>
               </table>
                
                
               <table align="center" cellpadding="0" cellspacing="0" width="100%"> 
                     <tr>
                        <td align="right" valign="top" width="50%"><img src="http://larry.webmascot.com/carhoodnewsletter/paid-icon.png" alt="PAID"  /></td>
                        <td align="left" valign="top" width="50%">
<table align="center" cellpadding="0" cellspacing="0" width="100%">
  <tr>
    <td align="left" valign="top" width="52%" style="color: rgba(0,0,0,0.9);font-size: 14px;font-family:Arial, Helvetica, sans-serif; text-transform:uppercase;"> <strong>SUBTOTAL</strong></td>
    <td align="right" valign="top" width="28%" style="color: rgba(0,0,0,0.9);font-size: 14px;font-family:Arial, Helvetica, sans-serif;"><strong>$100.00</strong></td>
    <td align="left" width="20%" style="color: rgba(0,0,0,0.9);font-size: 13px;font-family:Arial, Helvetica, sans-serif;"><strong>&nbsp;Inc GST</strong></td>
  </tr>
  <tr>
    <td align="left" valign="top" width="52%" style="color: rgba(0,0,0,0.9);font-size: 14px;font-family:Arial, Helvetica, sans-serif; text-transform:uppercase;"><strong>Excess Protection</strong></td>
    <td align="right" valign="top" width="28%" style="color: rgba(0,0,0,0.9);font-size: 14px;font-family:Arial, Helvetica, sans-serif;"><strong>$50.00</strong></td>
    <td align="left" width="20%" style="color: rgba(0,0,0,0.9);font-size: 13px;font-family:Arial, Helvetica, sans-serif;"><strong>&nbsp;Inc GST</strong></td>
  </tr>
  <tr>
    <td align="left" valign="top" width="52%" style="color: rgba(0,0,0,0.9);font-size: 14px;font-family:Arial, Helvetica, sans-serif; text-transform:uppercase;"><strong>Accessories</strong> </td>
    <td align="right" valign="top" width="28%" style="color: rgba(0,0,0,0.9);font-size: 14px;font-family:Arial, Helvetica, sans-serif;"><strong>$20.00</strong></td>
    <td align="left" width="20%" style="color: rgba(0,0,0,0.9);font-size: 13px;font-family:Arial, Helvetica, sans-serif;"><strong>&nbsp;Inc GST</strong></td>
  </tr>
  <tr>
    <td align="left" valign="top" width="52%" style="color: rgba(0,0,0,0.9);font-size: 14px;font-family:Arial, Helvetica, sans-serif; text-transform:uppercase;"><strong>Coupon</strong></td>
  <td align="right" valign="top" width="28%" style="color: rgba(0,0,0,0.9);font-size: 14px;font-family:Arial, Helvetica, sans-serif;"><strong>$-10.00</strong></td>
  <td align="left" width="20%" style="color: rgba(0,0,0,0.9);font-size: 13px;font-family:Arial, Helvetica, sans-serif;">&nbsp;</td>
  </tr>
  <tr>
    <td align="left" valign="top" width="52%" style="color: rgba(0,0,0,0.9);font-size: 14px;font-family:Arial, Helvetica, sans-serif; text-transform:uppercase;"><strong>GST TOtal</strong></td>
    <td align="right" valign="top" width="28%" style="color: rgba(0,0,0,0.9);font-size: 14px;font-family:Arial, Helvetica, sans-serif;"><strong>($-14.54</strong></td>
  <td align="left" width="20%" style="color: rgba(0,0,0,0.9);font-size: 14px;font-family:Arial, Helvetica, sans-serif;"><strong><span style="color:red">*</span>)</strong></td>
  </tr>
  <tr>
    <td align="left" valign="top" width="52%" style="color: rgba(0,0,0,0.9);font-size: 14px;font-family:Arial, Helvetica, sans-serif; text-transform:uppercase;"><strong>GRand Total</strong></td>
    <td align="right" valign="top" width="28%" style="color: rgba(0,0,0,0.9);font-size: 14px;font-family:Arial, Helvetica, sans-serif;"><strong>$160.00</strong></td>
  <td align="left" width="20%" style="color: rgba(0,0,0,0.9);font-size: 13px;font-family:Arial, Helvetica, sans-serif;"><strong>&nbsp;Inc GST</strong></td>
  </tr>
</table>

	
                        </td>
                     </tr>
               </table>
                

            </td>
            <td width="40"></td>
        </tr>
        
        <tr><td colspan="3" height="40"></td></tr>
    </table>
</td>
</tr>
<tr><td align="center" valign="top" height="40"></td></tr>
</table>
</body>
</html>






EOD;








	// To send HTML mail, the Content-type header must be set
	$headers  = 'MIME-Version: 1.0' . "\r\n";
	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
	$headers .= 'To: WebAlive <forms@webalive.biz>' . "\r\n";


	mail($to, $subject, $html, $headers);

?>


 

 