<?php
	$to = 'webalive.srv@gmail.com,khaled@bitmascot.com,webalive.srv@yahoo.com';
 	$subject = 'Welcome Carhood';
$html = <<<EOD
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Renter</title>
<style>
* {
	margin: 0;
	padding: 0;
}
</style>
</head>
<body style="background:#eeeeee;">
<table width="100%" border="0" cellspacing="0" cellpadding="0"  bgcolor="#eeeeee" align="center">
  <tr>
    <td valign="top" align="center"><table width="750" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center">
        <tr>
          <td valign="top"  style="padding:35px; background:#f1f5f7;"><table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#f1f5f7" align="center" style="padding:0;">
              <tr>
                <td valign="middle"  align="left"><a href="#"> <img src="http://larry.webmascot.com/carhoodnewsletter-new/logo_img.png" width="171" height="35" border="0" alt="Logo"  /></a></td>
                <td style="background:#f1f5f7;width:300px;"></td>
                <td valign="middle"  align="left"><table align="left" cellpadding="0" cellspacing="0">
                    <tr>
                      <td align="left" valign="middle"><img src="http://larry.webmascot.com/carhoodnewsletter-new/callus_img.png" alt="call" style="vertical-align:middle;"></td>
                      <td align="left" valign="top"><a href="tel:1300 466 663" style="text-decoration:none;color:#2b4a81; font-size:12px;font-family:Arial, Helvetica, sans-serif;">1300 466 663</a></td>
                    </tr>
                    <tr>
                      <td align="left" valign="middle"><img src="http://larry.webmascot.com/carhoodnewsletter-new/mailicon_img.png" alt="call" style="vertical-align:middle;"></td>
                      <td align="left" valign="top">&nbsp;<a href="mailto:support@carhood.com.au" style="text-decoration:none;color:#2b4a81; font-size:12px;font-family: Arial, Helvetica, sans-serif;">support@carhood.com.au</a></td>
                    </tr>
                  </table></td>
              </tr>
            </table></td>
        </tr>
        <tr>
          <td valign="top" style="padding:35px;"><h3 style="color:#2b4a81; font-size:20px; text-align:center;font-family: Arial, Helvetica, sans-serif;font-weight:600;line-height:26px; padding:0; margin:0;"> YOUR CAR LISTING EARNINGS STATEMENT </h3>
            <p style="color:#060606; font-size:18px; text-align:center;font-family: Arial, Helvetica, sans-serif;margin:0; padding:0; padding-top:10px; line-height:20px;"> Transaction #: <b>SYDOWN1234</b> </p></td>
        </tr>
        <tr>
          <td valign="top" style="padding-top:0; padding-bottom:0; padding-left:35px; padding-right:35px;color:#060606; font-size:13px; text-align:left;font-family: Arial, Helvetica, sans-serif;line-height:20px;"><b>Hey Rid Wilson</b>, </td>
        </tr>
        <tr>
          <td valign="top" style="padding-top:0; padding-bottom:0; padding-left:35px; padding-right:35px;color:#060606; font-size:12px; text-align:left;font-family: Arial, Helvetica, sans-serif;line-height:20px;"> Thanks for listing your car with Carhood. We look forward to seeing you next time! </td>
        </tr>
        <tr>
          <td height="40"></td>
        </tr>
        <tr>
          <td valign="top" align="center" style="padding:0 35px;"><table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center" style="border-top:1px solid #c2c2c2;" >
              <tr>
                <td valign="top" width="20%" style="text-align:left; padding:15px 0;"><img src="http://larry.webmascot.com/carhoodnewsletter-new/car.jpg"  width="73" height="99" border="0" alt="Logo" /></td>
                <td valign="top" width="80%" style="text-align:left; padding:15px 0;"><h3 style="color:#000; font-size:14px; text-align:left;font-family: Arial, Helvetica, sans-serif;font-weight:600;line-height:20px; padding:0; margin:0;"> FORD TRANSIT </h3>
                  <p style="color:#060606; font-size:12px; text-align:left;font-family: Arial, Helvetica, sans-serif;margin:0; padding:0; line-height:20px;"> Auto Van </p></td>
              </tr>
            </table></td>
        </tr>
        <tr>
          <td height="20"></td>
        </tr>
        <tr>
          <td valign="top" align="center" style="padding:35px; padding-top:0;">
          
 
      <h3 style="color:#000; font-size:26px; text-align:center;font-family: Arial, Helvetica, sans-serif;font-weight:bold;line-height:26px; padding:0; margin:0; text-transform:uppercase;">How much have you saved?</h3>
     
      <h3 style="color:#2b4a81; font-size:26px; text-align:center;font-family: Arial, Helvetica, sans-serif;font-weight:bold;line-height:26px; padding:0; margin:0; text-transform:uppercase;">How much have you made?&nbsp;</h3>
  

  </td>
        </tr>
                                        
        
        
         
        
        
        
        <tr>
          <td valign="top"  style="padding:10px 35px;"><table width="100%" cellspacing="0" cellpadding="0" align="center">
              <tr>
                <td valign="top" align="left" bgcolor="#eeeeee"  style="padding-left:15px; padding-right:15px; padding-top: 20px; padding-bottom:30px;"><table   cellspacing="0" cellpadding="0" align="center">
                    <tr>
                    
                      <td valign="top" align="center"  width="135" >
                      
                      
<table cellpadding="0" cellspacing="0" border="0" style="border-collapse:collapse;" bgcolor="#eee">
<tr><td colspan="3" valign="bottom" width="104"><img  src="http://larry.webmascot.com/carhoodnewsletter-new/bubble-1/top.png" alt=""   width="104" height="26"   /></td></tr>
<tr>
<td valign="bottom" width="12" style="border-right:1px solid #00a4e8;"><img  src="http://larry.webmascot.com/carhoodnewsletter-new/bubble-1/left.png" alt=""  width="12" height="54"  /></td>
<td valign="top" width="79" bgcolor="#00a4e8" style="color:#fff;text-transform:uppercase; font-size:12px; text-align:center;font-family: Arial, Helvetica, sans-serif;margin:0; padding:0;">
 On average                               
<p style="color:#fff;text-transform:uppercase; font-size:17px; text-align:center;font-family: Arial, Helvetica, sans-serif;margin:0; padding:2px 0 0 0; line-height:20px;"> <b>$238</b></p>
</td>
<td valign="bottom" width="12"><img  src="http://larry.webmascot.com/carhoodnewsletter-new/bubble-1/right.png" alt=""   width="12" height="54"   /></td>
</tr>
<tr>
<td colspan="3" valign="top"  width="104"><img  src="http://larry.webmascot.com/carhoodnewsletter-new/bubble-1/down.png" alt=""  width="104" height="26"     /></td>
</tr>
</table>

                        
                        
                           <table cellspacing="0" cellpadding="0" align="center" width="100%" >
                                <tr><td align="center" valign="top" height="1">&nbsp;</td></tr>
                           		<tr><td align="center" valign="top"><img  src="http://larry.webmascot.com/carhoodnewsletter-new/icon-1.png" alt="icon" width="50" height="50" /></td></tr>
                           </table>
                        
                        <p style="color:#353535; font-size:13px; text-align:center;font-family: Arial, Helvetica, sans-serif;margin:0; padding:0; padding-top:10px; line-height:20px;"> <b>SAVE ON PARKING</b></p>
                        
                        <p style="color:#353535; font-size:12px; text-align:center;font-family: Arial, Helvetica, sans-serif;margin:0; padding:0;  padding-top:4px; line-height:17px;"> You saved this much money on parking while you were away.</p></td>
                        
                        
                        
                        
                        
                      <td valign="top" align="center" width="50" style="color:#666666; font-size:43px; text-align:center;font-family: Arial, Helvetica, sans-serif; padding-top:30px;"> + </td>
                      <td valign="top" align="center"  width="135" >
                      
                      
                      
<table cellpadding="0" cellspacing="0" border="0" style="border-collapse:collapse;" bgcolor="#eee">
<tr><td colspan="3" valign="bottom" width="104"><img  src="http://larry.webmascot.com/carhoodnewsletter-new/bubble-2/top.png" alt=""   width="104" height="26"   /></td></tr>
<tr>
<td valign="bottom" width="12" style="border-right:1px solid #eeab52;"><img  src="http://larry.webmascot.com/carhoodnewsletter-new/bubble-2/left.png" alt=""  width="12" height="54"  /></td>
<td valign="top" width="79" bgcolor="#eeab52" style="color:#fff;text-transform:uppercase; font-size:12px; text-align:center;font-family: Arial, Helvetica, sans-serif;margin:0; padding:0;">
 On average                               
<p style="color:#fff;text-transform:uppercase; font-size:17px; text-align:center;font-family: Arial, Helvetica, sans-serif;margin:0; padding:2px 0 0 0; line-height:20px;"> <b>$238</b></p>
</td>
<td valign="bottom" width="12"><img  src="http://larry.webmascot.com/carhoodnewsletter-new/bubble-2/right.png" alt=""   width="12" height="54"   /></td>
</tr>
<tr>
<td colspan="3" valign="top"  width="104"><img  src="http://larry.webmascot.com/carhoodnewsletter-new/bubble-2/down.png" alt=""  width="104" height="26"     /></td>
</tr>
</table>

                        
                           <table cellspacing="0" cellpadding="0" align="center" width="100%" >
                                <tr><td align="center" valign="top" height="1">&nbsp;</td></tr>
                           		<tr><td align="center" valign="top"><img  src="http://larry.webmascot.com/carhoodnewsletter-new/icon-2.png" alt="icon" width="50" height="50" /></td></tr>
                           </table>

                        
                        <p style="color:#353535; font-size:13px; text-align:center;font-family: Arial, Helvetica, sans-serif;margin:0; padding:0; padding-top:10px; line-height:20px;"> <b>PAID TO YOU</b></p>
                        <p style="color:#353535; font-size:12px; text-align:center;font-family: Arial, Helvetica, sans-serif;margin:0; padding:0;  padding-top:4px; line-height:17px;"> You earned this amount while your car was rented</p></td>
                        
                        
                        
                      <td valign="top" align="center" width="50" style="color:#666666; font-size:43px; text-align:center;font-family: Arial, Helvetica, sans-serif; padding-top:30px;"> + </td>
                      <td valign="top" align="center"  width="135">
                      
<table cellpadding="0" cellspacing="0" border="0" style="border-collapse:collapse;" bgcolor="#eee">
<tr><td colspan="3" valign="bottom" width="104"><img  src="http://larry.webmascot.com/carhoodnewsletter-new/bubble-3/top.png" alt=""   width="104" height="26"   /></td></tr>
<tr>
<td valign="bottom" width="12" style="border-right:1px solid #61ce5d;"><img  src="http://larry.webmascot.com/carhoodnewsletter-new/bubble-3/left.png" alt=""  width="12" height="54"  /></td>
<td valign="top" width="79" bgcolor="#61ce5d" style="color:#fff;text-transform:uppercase; font-size:12px; text-align:center;font-family: Arial, Helvetica, sans-serif;margin:0; padding:0;">
 On average                               
<p style="color:#fff;text-transform:uppercase; font-size:17px; text-align:center;font-family: Arial, Helvetica, sans-serif;margin:0; padding:2px 0 0 0; line-height:20px;"> <b>$238</b></p>
</td>
<td valign="bottom" width="12"><img  src="http://larry.webmascot.com/carhoodnewsletter-new/bubble-3/right.png" alt=""   width="12" height="54"   /></td>
</tr>
<tr>
<td colspan="3" valign="top"  width="104"><img  src="http://larry.webmascot.com/carhoodnewsletter-new/bubble-3/down.png" alt=""  width="104" height="26"     /></td>
</tr>
</table>




                           <table cellspacing="0" cellpadding="0" align="center" width="100%" >
                                <tr><td align="center" valign="top" height="1">&nbsp;</td></tr>
                           		<tr><td align="center" valign="top"><img  src="http://larry.webmascot.com/carhoodnewsletter-new/icon-3.png" alt="icon" width="50" height="50" /></td></tr>
                           </table>
                        
                        
                        
                        <p style="color:#353535; font-size:13px; text-align:center;font-family: Arial, Helvetica, sans-serif;margin:0; padding:0; padding-top:10px; line-height:20px;"> <b>CAR CLEAN</b></p>
                        <p style="color:#353535; font-size:12px; text-align:center;font-family: Arial, Helvetica, sans-serif;margin:0; padding:0;  padding-top:4px; line-height:17px;"> You received a free car clean whilst you were away.</p></td>
                      <td valign="top" align="center" width="50" style="color:#666666; font-size:43px; text-align:center;font-family: Arial, Helvetica, sans-serif; padding-top:30px;"> = </td>
                      <td valign="top" align="center"  width="135" >
                      
<table cellpadding="0" cellspacing="0" border="0" style="border-collapse:collapse;" bgcolor="#eee">
<tr><td colspan="3" valign="bottom" width="104"><img  src="http://larry.webmascot.com/carhoodnewsletter-new/bubble-4/top.png" alt=""   width="104" height="26"   /></td></tr>
<tr>
<td valign="bottom" width="12" style="border-right:1px solid #313133;"><img  src="http://larry.webmascot.com/carhoodnewsletter-new/bubble-4/left.png" alt=""  width="12" height="54"  /></td>
<td valign="top" width="79" bgcolor="#313133" style="color:#fff;text-transform:uppercase; font-size:12px; text-align:center;font-family: Arial, Helvetica, sans-serif;margin:0; padding:0;">
 On average                               
<p style="color:#fff;text-transform:uppercase; font-size:17px; text-align:center;font-family: Arial, Helvetica, sans-serif;margin:0; padding:2px 0 0 0; line-height:20px;"> <b>$238</b></p>
</td>
<td valign="bottom" width="12"><img  src="http://larry.webmascot.com/carhoodnewsletter-new/bubble-4/right.png" alt=""   width="12" height="54"   /></td>
</tr>
<tr>
<td colspan="3" valign="top"  width="104"><img  src="http://larry.webmascot.com/carhoodnewsletter-new/bubble-4/down.png" alt=""  width="104" height="26"     /></td>
</tr>
</table>
                      
                      
                      
                        
                        
                           <table cellspacing="0" cellpadding="0" align="center" width="100%" >
                                <tr><td align="center" valign="top" height="1">&nbsp;</td></tr>
                           		<tr><td align="center" valign="top"><img  src="http://larry.webmascot.com/carhoodnewsletter-new/save-money.png" alt="icon" width="50" height="50" /></td></tr>
                           </table>

                        
                        
                        <p style="color:#353535; font-size:13px; text-align:center;font-family: Arial, Helvetica, sans-serif;margin:0; padding:0; padding-top:10px; line-height:20px;"> <b>VALUE</b></p>
                        <p style="color:#353535; font-size:12px; text-align:center;font-family: Arial, Helvetica, sans-serif;margin:0; padding:0;  padding-top:4px; line-height:17px;"> The money you made & saved, all while helping a fellow traveler.</p></td>
                    </tr>
                  </table></td>
              </tr>
            </table></td>
        </tr>
        
        
         
        <tr><td   width="100%" valign="middle" height="30" align="center"></td></tr>
        
        
         
        
        
        
        
        <tr>
          <td valign="top"  style="padding:35px;" align="center"><table width="60%" cellspacing="0" cellpadding="0" align="center">
              <tr>
                <td valign="top" align="center">
                	
                   
                  <table width="100%" style="border: 1px solid #fff;" cellspacing="0" cellpadding="0" align="center">
                    <tr>
                      <td style="padding:5px 0; margin-bottom:0; margin-top:0;" width="100%" valign="middle" align="center" colspan="2"><table align="center" cellpadding="0" cellspacing="0" width="70%">
                          <tr>
                            <td width="100%" valign="middle" align="center" colspan="2"><h4 style="color:#2b4a81;font-size:14px;text-align:center;font-family: Arial, Helvetica, sans-serif;font-weight:bold; padding:0; margin-bottom:0; margin-top:0; text-transform:uppercase;"> Summary</h4></td>
                          </tr>
                          <tr>
                            <td width="100%" valign="middle" align="center" colspan="2" height="10"></td>
                          </tr>
                          <tr>
                            <td width="70%" valign="middle" align="left"><p style="color:#353535;font-size:13px;text-align:left;font-family: Arial, Helvetica, sans-serif;font-weight:normal; padding:0; margin-bottom:0; margin-top:0;"> &nbsp; Days Listed&nbsp;:</p></td>
                            <td width="30%" valign="middle" align="left"><p style="color:#353535;font-size:13px;text-align:left;font-family: Arial, Helvetica, sans-serif;font-weight:normal; padding:0; margin-bottom:0; margin-top:0;"> 20</p></td>
                          </tr>
                          <tr>
                            <td width="70%" valign="middle" align="left"><p style="color:#353535;font-size:13px;text-align:left;font-family: Arial, Helvetica, sans-serif;font-weight:normal; padding:0; margin-bottom:0; margin-top:0;"> &nbsp; Days Rented out&nbsp;:</p></td>
                            <td width="30%" valign="middle" align="left"><p style="color:#353535;font-size:13px;text-align:left;font-family: Arial, Helvetica, sans-serif;font-weight:normal; padding:0; margin-bottom:0; margin-top:0;"> 12</p></td>
                          </tr>
                          <tr>
                            <td width="70%" valign="middle" align="left"><p style="color:#353535;font-size:13px;text-align:left;font-family: Arial, Helvetica, sans-serif;font-weight:normal; padding:0; margin-bottom:0; margin-top:0;"> &nbsp; No. of Rentals&nbsp;:</p></td>
                            <td width="30%" valign="middle" align="left"><p style="color:#353535;font-size:13px;text-align:left;font-family: Arial, Helvetica, sans-serif;font-weight:normal; padding:0; margin-bottom:0; margin-top:0;"> 8</p></td>
                          </tr>
                        </table></td>
                    </tr>

                    <tr><td valign="top" align="center" colspan="2" height="40">&nbsp;</td></tr>


                    <tr>
                      <td style="color:#2b4a81;font-size:14px;text-align:center;font-family: Arial, Helvetica, sans-serif;
font-weight:normal; text-transform:uppercase;" valign="top" align="center" colspan="2"><b>Car OWNER'S Earning</b></td>
                    </tr>
                    <tr><td valign="top" align="center" colspan="2" height="1">&nbsp;</td></tr>


                    
                    
                    <tr>
                      <td style="background-color:#fff;border-top: 1px solid #ccc;border-bottom: 1px solid #ccc;padding:5px 0; margin-bottom:0; margin-top:0;"
                                    width="85%" valign="middle" align="left"><p style="color:#353535;font-size:13px;text-align:left;font-family: Arial, Helvetica, sans-serif;
                            font-weight:normal; padding:0; margin-bottom:0; margin-top:0;">&nbsp; Actual Earning&nbsp;:</p></td>
                      <td style="background-color:#fff;border-top: 1px solid #ccc;border-bottom: 1px solid #ccc;border-left: 1px solid #fff;padding:5px 0; margin-bottom:0; margin-top:0;"
                                     width="15%" valign="middle" align="left"><p style="color:#353535;font-size:13px;text-align:left;font-family: Arial, Helvetica, sans-serif;
                            font-weight:normal;padding:0; margin-bottom:0; margin-top:0;">&nbsp; 35.00%</p></td>
                    </tr>
                    <tr>
                      <td style="background-color:#fff;border-bottom: 1px solid #ccc;padding:5px 0; margin-bottom:0; margin-top:0;"
                                    width="85%" valign="middle" align="left"><p style="color:#353535;font-size:13px;text-align:left;font-family: Arial, Helvetica, sans-serif;
                            font-weight:normal; padding:0; margin-bottom:0; margin-top:0;">&nbsp; Fixed Earning&nbsp;:</p></td>
                      <td style="background-color:#fff;border-bottom: 1px solid #ccc;border-left: 1px solid #fff;padding:5px 0; margin-bottom:0; margin-top:0;"
                                     width="15%" valign="middle" align="left"><p style="color:#353535;font-size:13px;text-align:left;font-family: Arial, Helvetica, sans-serif;
                            font-weight:normal;padding:0; margin-bottom:0; margin-top:0;">&nbsp; 35.00%</p></td>
                    </tr>
                    <tr>
                      <td style="background-color:#fff;border-bottom: 1px solid #ccc;padding:5px 0; margin-bottom:0; margin-top:0;"
                                    width="85%" valign="middle" align="left"><p style="color:#353535;font-size:13px;text-align:left;font-family: Arial, Helvetica, sans-serif;
                            font-weight:normal; padding:0; margin-bottom:0; margin-top:0;">&nbsp; Coupon Code Applied&nbsp;:</p></td>
                      <td style="background-color:#fff;border-bottom: 1px solid #ccc;border-left: 1px solid #fff;padding:5px 0; margin-bottom:0; margin-top:0;"
                                     width="15%" valign="middle" align="left"><p style="color:#353535;font-size:13px;text-align:left;font-family: Arial, Helvetica, sans-serif;
                            font-weight:normal;padding:0; margin-bottom:0; margin-top:0;">&nbsp; N/A</p></td>
                    </tr>
                    <tr>
                      <td style="background-color:#fff;border-bottom: 1px solid #ccc;padding:5px 0; margin-bottom:0; margin-top:0;"
                                    width="85%" valign="middle" align="left"><p style="color:#353535;font-size:13px;text-align:left;font-family: Arial, Helvetica, sans-serif;
                            font-weight:normal; padding:0; margin-bottom:0; margin-top:0;">&nbsp; Addition&nbsp;:</p></td>
                      <td style="background-color:#fff;border-bottom: 1px solid #ccc;border-left: 1px solid #fff;padding:5px 0; margin-bottom:0; margin-top:0;"
                                     width="15%" valign="middle" align="left"><p style="color:#353535;font-size:13px;text-align:left;font-family: Arial, Helvetica, sans-serif;
                            font-weight:normal;padding:0; margin-bottom:0; margin-top:0;">&nbsp; $0.00</p></td>
                    </tr>
                    <tr>
                      <td style="background-color:#fff;border-bottom: 1px solid #ccc;padding:5px 0; margin-bottom:0; margin-top:0;"
                                     width="15%" valign="middle" align="left"><p style="color:#353535;font-size:13px;text-align:left;font-family: Arial, Helvetica, sans-serif;
                            font-weight:normal; padding:0; margin-bottom:0; margin-top:0;">&nbsp; Deduction&nbsp;:</p></td>
                      <td style="background-color:#fff;border-bottom: 1px solid #ccc;border-left: 1px solid #fff;padding:5px 0; margin-bottom:0; margin-top:0;"
                                    width="85%" valign="middle" align="left"><p style="color:#353535;font-size:13px;text-align:left;font-family: Arial, Helvetica, sans-serif;
                            font-weight:normal;padding:0; margin-bottom:0; margin-top:0;">&nbsp; $0.00</p></td>
                    </tr>
                    <tr>
                      <td style="background-color:#fff;padding:5px 0; margin-bottom:0; margin-top:0;"
                                    width="85%" valign="middle" align="left"><p style="color:#353535;font-size:13px;text-align:left;font-family: Arial, Helvetica, sans-serif;
                            font-weight:normal; padding:0; margin-bottom:0; margin-top:0;"><b>&nbsp; Total Earning</b>&nbsp;:</p></td>
                      <td style="background-color:#fff;border-left: 1px solid #fff;padding:5px 0; margin-bottom:0; margin-top:0;"
                                     width="15%" valign="middle" align="left"><p style="color:#353535;font-size:13px;text-align:left;font-family: Arial, Helvetica, sans-serif;
                            font-weight:normal;padding:0; margin-bottom:0; margin-top:0;">&nbsp; <b>$0.00</b></p></td>
                    </tr>
                    <tr>
                      <td style="padding:5px 0; margin-bottom:0; margin-top:0;" width="100%" valign="middle" align="center" colspan="2" height="30"></td>
                    </tr>
                  </table>
                  
                  </td>
              </tr>
            </table></td>
        </tr>
        <tr>
          <td valign="top" height="10"></td>
        </tr>
        <tr>
          <td valign="top" align="center" style="padding:35px; background:#555555;"><table align="center" width="100%" cellpadding="0" cellspacing="0" border="0">
              <tr>
                <td valign="top" align="left" style="color:#fff;font-size:14px; font-weight:bold; text-align:left;font-family: Arial, Helvetica, sans-serif;margin:0; padding:0 0 5px 0; line-height:20px; text-transform:uppercase;"> @CARHOOD </td>
                <td valign="top" align="left"><table align="right" width="165" cellpadding="0" cellspacing="0" border="0">
                    <tr>
                      <td valign="top" align="left"><a href="" target="_blank"><img  src="http://larry.webmascot.com/carhoodnewsletter-new/voyage_img.png" alt="" /></a></td>
                      <td valign="top" align="left"><a href="https://www.facebook.com/carhood.com.au" target="_blank"><img  src="http://larry.webmascot.com/carhoodnewsletter-new/fb_img.png" alt="" /></a></td>
                      <td valign="top" align="left"><a href="https://twitter.com/carhood_" target="_blank"><img  src="http://larry.webmascot.com/carhoodnewsletter-new/twitter_img.png"  alt=""/></a></td>
                      <td valign="top" align="left"><a href="https://www.linkedin.com/company/carhood" target="_blank"><img  src="http://larry.webmascot.com/carhoodnewsletter-new/linkedin_img.png" alt="" /></a></td>
                    </tr>
                  </table></td>
              </tr>
            </table></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>

 

EOD;
	// To send HTML mail, the Content-type header must be set
	$headers  = 'MIME-Version: 1.0' . "\r\n";
	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
	$headers .= 'To: WebAlive <forms@webalive.biz>' . "\r\n";
	mail($to, $subject, $html, $headers);
?>


 

 