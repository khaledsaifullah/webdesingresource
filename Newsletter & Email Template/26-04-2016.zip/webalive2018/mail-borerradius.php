<?php
	$to = 'webalive.srv@gmail.com';
	
 	
	$subject = 'Welcome webalive';
	
	
$html = <<<EOD


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Newsletter WebAlive</title>
<style type="text/css">
* {
	padding-bottom: 0px;
	padding-top: 0px;
	padding-left: 0px;
	margin: 0px;
	padding-right: 0px
}
html,body{
	background-color:#f2f2f2;	
}
</style>
</head>

<body style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px">
<table style="font-family:Arial, Helvetica, sans-serif;color: #676767" cellspacing="0" cellpadding="0" border="0" bgcolor="#f2f2f2" width="100%">
  <tbody>
    <tr>
      <td height="40">&nbsp;</td>
    </tr>
    <tr>
      <td align="center"><table cellspacing="0" cellpadding="0" border="0" bgcolor="#ffffff" width="750">
          <tbody>
            <tr>
              <td colspan="3" height="40">&nbsp;</td>
            </tr>
            <tr>
              <td width="40">&nbsp;</td>
              <td align="left" style="text-align:left;"><a href="https://www.webalive.com.au/"><img alt="WebAlive" src="https://33t2km132djh3q21qa47elmw-wpengine.netdna-ssl.com/wp-content/themes/webalive/images/logo.png" /></a></td>
              <td width="40">&nbsp;</td>
            </tr>
            <tr>
              <td colspan="3" height="60">&nbsp;</td>
            </tr>



<tr>
              <td width="40">&nbsp;</td>
              <td align="left">
              <table width="100%" cellspacing="0" cellpadding="0" border="0" align="left"> 
                        <tbody><tr>
                        <td style="line-height:20px;color:#000;font-size:14px; font-weight:bold;text-align:left;font-family:Arial, Helvetica, sans-serif;" valign="top" align="left">Dear XYZ,</td></tr>
                    	<tr>
                        <td style="line-height:20px;color:#000;font-size:14px; font-weight:normal;text-align:left;font-family:Arial, Helvetica, sans-serif;" valign="top" align="left">Thank you for ordering products from WebAlive. The following are the details of your order:</td></tr>
                    </tbody></table>
              </td>
              <td width="40">&nbsp;</td>
            </tr>
            
            <tr><td colspan="3" height="35"></td></tr>
            
   <tr>
              <td width="40">&nbsp;</td>
              <td align="left">
              <table width="100%" cellspacing="0" cellpadding="0" border="0" align="left"> 
                        <tbody><tr>
                        <td style="line-height:20px;color:#000;font-size:14px; font-weight:bold;text-align:left;font-family:Arial, Helvetica, sans-serif;" valign="top" align="left">Invoice ID - 001</td></tr>
                    	<tr>
                        <td style="line-height:20px;color:#000;font-size:14px; font-weight:normal;text-align:left;font-family:Arial, Helvetica, sans-serif;" valign="top" align="left">Date:03/07/2018</td></tr>
                    </tbody></table>
              </td>
              <td width="40">&nbsp;</td>
            </tr>         


            <tr><td colspan="3" height="35"></td></tr>
            <tr>
              <td width="40">&nbsp;</td>
              <td>
                <table cellspacing="0" cellpadding="0" border="0" width="100%">
  <thead>
    <tr bgcolor="#f4f4f4">
      <th width="100%" colspan="2" align="left" style="padding-left:15px;padding-top:8px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">
      User Info</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td width="41%" align="left"   valign="top"  style="padding-top:15px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">Category: </td>
      <td width="59%" align="left"   valign="top"  style="padding-top:15px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">Property</td>
    </tr>
    <tr>
      <td width="41%" align="left"   valign="top"  style="padding-top:8px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">Name: </td>
      <td width="59%" align="left"   valign="top"  style="padding-top:8px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">Rabiul Islam</td>
    </tr>
    <tr>
      <td width="41%" align="left"   valign="top"  style="padding-top:8px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">Address: </td>
      <td width="59%" align="left"   valign="top"  style="padding-top:8px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">England, birminghum</td>
    </tr>
    <tr>
      <td width="41%" align="left"   valign="top"  style="padding-top:8px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">Phone: </td>
      <td width="59%" align="left"   valign="top"  style="padding-top:8px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">
      	<a href="tel:2324445" style="color:#f47520; text-decoration:none;">2324445</a>
      </td>
    </tr>
    <tr>
      <td width="41%" align="left"   valign="top"  style="padding-top:8px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">Email: </td>
      <td width="59%" align="left"   valign="top"  style="padding-top:8px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">
      <a href="mailto:john@gmail.com" target="_blank" style="color:#f47520; text-decoration:none;">john@gmail.com</a></td>
    </tr>
    <tr>
      <td width="41%" align="left"   valign="top"  style="padding-top:8px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">City </td>
      <td width="59%" align="left"   valign="top"  style="padding-top:8px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">London</td>
    </tr>
    <tr>
      <td width="41%" align="left"   valign="top"  style="padding-top:8px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">Postcode </td>
      <td width="59%" align="left"   valign="top"  style="padding-top:8px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">3341</td>
    </tr>
    <tr>
      <td width="41%" align="left"   valign="top"  style="padding-top:8px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">State </td>
      <td width="59%" align="left"   valign="top"  style="padding-top:8px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">QLD</td>
    </tr>
  </tbody>
</table>
 
              </td>
              <td width="40">&nbsp;</td>
            </tr>
            <tr><td colspan="3" height="35"></td></tr>



            <tr><td colspan="3" height="35"></td></tr>
            <tr>
              <td width="40">&nbsp;</td>
              <td>
                <table cellspacing="0" cellpadding="0" border="0" width="100%">
               <thead>
    <tr bgcolor="#f4f4f4">
      <th width="100%" colspan="2" align="left" style="padding-left:15px;padding-top:8px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">
      Social Media</th>
    </tr>
  </thead>
               <tbody>
<tr>
	<td width="41%" align="left"   valign="top"  style="padding-top:15px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">Facebook</td>	
    <td width="59%" align="left"   valign="top"  style="padding-top:15px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;"><a href="https://facebook.com/johndoe" target="_blank" style="color:#f47520; text-decoration:none;">https://facebook.com/johndoe</a></td>
</tr>
<tr>
	<td width="41%" align="left"   valign="top"  style="padding-top:8px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">Twitter</td>	
    <td width="59%" align="left"   valign="top"  style="padding-top:8px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">
    <a href="https://twitter.com/johnode" target="_blank" style="color:#f47520; text-decoration:none;">https://twitter.com/johnode</a></td>
</tr>
<tr><td width="41%" align="left"   valign="top"  style="padding-top:8px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">Linkedin</td>	
<td width="59%" align="left"   valign="top"  style="padding-top:8px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">
<a href="https://linkeding.com/johndoe" target="_blank" style="color:#f47520; text-decoration:none;">https://linkeding.com/johndoe</a></td>
</tr>
<tr><td width="41%" align="left"   valign="top"  style="padding-top:8px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">Youtube</td>	
<td width="59%" align="left"   valign="top"  style="padding-top:8px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;"><a href="https://youtube.com/channel/johndoe" target="_blank" style="color:#f47520; text-decoration:none;">https://youtube.com/channel/johndoe</a></td>
</tr>
<tr><td width="41%" align="left"   valign="top"  style="padding-top:8px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">Pinterest</td>	
<td width="59%" align="left"   valign="top"  style="padding-top:8px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;"><a href="https://pinterest.com/johndoe" target="_blank" style="color:#f47520; text-decoration:none;">https://pinterest.com/johndoe</a></td>
</tr>
 </tbody>
                </table> 
              </td>
              <td width="40">&nbsp;</td>
            </tr>
            <tr><td colspan="3" height="35"></td></tr>
             


            <tr><td colspan="3" height="35"></td></tr>
            <tr>
              <td width="40">&nbsp;</td>
              <td>
                <table cellspacing="0" cellpadding="0" border="0" width="100%">
      <thead>
    <tr bgcolor="#f4f4f4">
      <th width="100%" colspan="2" align="left" style="padding-left:15px;padding-top:8px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">
      Business Details</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td width="41%" align="left"   valign="top"  style="padding-top:15px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">
      Business Name: </td>
      <td width="59%" align="left"   valign="top"  style="padding-top:15px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">Property</td>
    </tr>
    <tr>
      <td width="41%" align="left"   valign="top"  style="padding-top:8px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">
      Your Business: </td>
      <td width="59%" align="left"   valign="top"  style="padding-top:8px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">Property</td>
    </tr>
    <tr>
      <td width="41%" align="left"   valign="top"  style="padding-top:8px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">
      Tell us a bit about your business: </td>
      <td width="59%" align="left"   valign="top"  style="padding-top:8px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">Tell us a little bit more about your business</td>
    </tr>
    
    <tr>
      <td width="41%" align="left"   valign="top"  style="padding-top:8px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">
      What is your business hours?</td>
      <td width="59%" align="left"   valign="top"  style="padding-top:8px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">What are your business hours?</td>
    </tr>
    <tr><td colspan="2" height="15"></td></tr>
    <tr>
      <td width="41%" align="left"   valign="top"  style="padding-top:8px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">
      What makes your business different from the rest?	 </td>
      <td width="59%" align="left"   valign="top"  style="padding-top:8px;padding-bottom:8px;color:#000000;font-size:16px;font-family:Arial, Helvetica, sans-serif;">Property</td>
    </tr>
  </tbody>
</table> 
              </td>
              <td width="40">&nbsp;</td>
            </tr>
            <tr><td colspan="3" height="35"></td></tr>




            <tr>
              <td width="40">&nbsp;</td>
              <td><b style="font-size: 12px; font-family:Arial, Helvetica, sans-serif;">Kind Regards</b><br />
                <b style="font-size: 14px; font-family:Arial, Helvetica, sans-serif; color: #333333">WebAlive Team</b></td>
              <td width="40">&nbsp;</td>
            </tr>
            <tr>
              <td colspan="3" height="40">&nbsp;</td>
            </tr>
          </tbody>
        </table></td>
    </tr>
    <tr>
      <td height="40">&nbsp;</td>
    </tr>
  </tbody>
</table>
</body>
</html>

 


EOD;

	// To send HTML mail, the Content-type header must be set
	$headers  = 'MIME-Version: 1.0' . "\r\n";
	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
	$headers .= 'To: WebAlive <webalive.srv@gmail.com>' . "\r\n";


	mail($to, $subject, $html, $headers);

?>


 

 