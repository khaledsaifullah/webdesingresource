<?php
	$to = 'khaled@bitmascot.com';
	
 	
	$subject = 'Welcome Autobil';
	
	
$html = <<<EOD

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Email Template</title>
<style>
* {
	margin: 0;
	padding: 0;
}
body {
	background-color: #f2f2f2;
	margin: 0;
	padding: 0;
	line-height: 20px;
	color: #353535;
	font-size: 14px;
	font-family: Arial, Helvetica, sans-serif;
}
p {
	line-height: 20px;
	color: #353535;
	font-size: 14px;
	text-align: left;
	font-family: Arial, Helvetica, sans-serif;
}
a {
	color: #353535;
	text-decoration: none;
}
.company-name {
	color: rgba(0,0,0,0.9);
	font-size: 20px;
	font-weight: bold;
}
.link-address {
	font-weight: bold;
}
.invoice-table {
	background-color: #ffffff;
}
</style>
</head>
<body>
<table align="center" cellpadding="0" cellspacing="0" width="100%" bgcolor="#f2f2f2">
  <tr>
    <td align="center" valign="top" height="40"></td>
  </tr>
  <tr>
    <td align="center" valign="top"><table align="center" cellpadding="0" cellspacing="0" width="750"   bgcolor="#ffffff" style="background:#ffffff">
        <tr>
          <td colspan="3" height="40"></td>
        </tr>
        <tr>
          <td width="40"></td>
          <td align="center" valign="top"><table align="center" cellpadding="0" cellspacing="0" width="100%">
              <tr>
                <td align="center" valign="top" colspan="2" style="text-align:center;"><a  href="#"><img src="http://larry.webmascot.com/rhinoemailtemplate/company-logo.png" alt="logo"  /></a></td>
              </tr>
              <tr>
                <td align="left" valign="top" height="30" colspan="2"></td>
              </tr>
              <tr>
                <td align="center" valign="top" colspan="2" style="color:#71a701;font-size:28px;font-family:Arial, Helvetica, sans-serif;text-align:center; padding:0; line-height:20px;"> Thank you for your order. </td>
              </tr>
              <tr>
                <td align="left" valign="top" height="30" colspan="2"></td>
              </tr>
              <tr>
                <td align="left" valign="top" colspan="2" style="color:#676767;font-size:16px;font-family:Arial, Helvetica, sans-serif;text-align:left;font-weight:bold; padding:0; line-height:20px;"> Dear Firstname Last name! </td>
              </tr>
              <tr>
                <td align="left" valign="top" height="15" colspan="2"></td>
              </tr>
              <tr>
                <td align="left" valign="top" colspan="2" style="color:#000000;font-size:18px;font-family:Arial, Helvetica, sans-serif;text-align:left;font-weight:bold; padding:0; line-height:20px;"> Your order details are as follows: </td>
              </tr>
              <tr>
                <td align="left" valign="top" height="20" colspan="2"></td>
              </tr>
              <tr>
                <td align="left" valign="top" width="50%" style="color:#353535;font-size:14px;text-align:left;font-family:Arial, Helvetica, sans-serif;font-weight:normal;"><b>Tax Invoice/ Order Number:</b> <b style="color:#000000;">ORD00120</b></td>
                <td align="right" valign="top" width="50%" style="color:#353535;font-size:14px;text-align:right;font-family:Arial, Helvetica, sans-serif;font-weight:normal;"><b style="color:#353535;">Order Date :</b> <b style="color:#000000;">21/11/2016</b></td>
              </tr>
              <tr>
                <td align="left" valign="top" colspan="2" height="20"></td>
              </tr>
              <tr>
                <td  align="left" valign="top" colspan="2" style="color:#676767;font-size:18px;text-align:left;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;"><b>Customer Details:</b></td>
              </tr>
              <tr>
                <td align="left" valign="top" colspan="2" height="10"></td>
              </tr>
              <tr>
                <td align="left" valign="top" colspan="2" height="1" style="border-top:1px solid #dadada;"></td>
              </tr>
              <tr>
                <td align="left" valign="top" colspan="2" height="10"></td>
              </tr>
            </table></td>
          <td width="40"></td>
        </tr>
        <tr>
          <td width="40"></td>
          <td align="center" valign="top"><table align="center" cellpadding="0" cellspacing="0" width="100%">
              <tr>
                <th  align="left" valign="top" width="50%" style="color:#000000;font-size:13px;text-align:left;font-family:Arial, Helvetica, sans-serif;
font-weight:bold;">DELIVERY ADDRESS</th>
                <th  align="left" valign="top" width="50%" style="color:#000000;font-size:13px;text-align:left;font-family:Arial, Helvetica, sans-serif;
font-weight:bold;">BILLING ADDRESS</th>
              </tr>
              <tr>
                <td  align="left" valign="top" width="50%"><p style="color:#353535;font-size:12px;text-align:left;font-family:Arial, Helvetica, sans-serif;font-weight:normal;line-height:20px"> Oliver Twist<br />
                    9 Yarra Street,<br />
                    South Yarra, Vic 3141<br />
                    Phone (03)8669064<br />
                    Fax (03)8669064<br />
                    info@webalive.com.au</p></td>
                <td  align="left" valign="top" width="50%"><p style="color:#353535;font-size:12px;text-align:left;font-family:Arial, Helvetica, sans-serif;font-weight:normal;line-height:20px"> Oliver Twist<br />
                    9 Yarra Street,<br />
                    South Yarra, Vic 3141<br />
                    Phone (03)8669064<br />
                    Fax (03)8669064<br />
                    info@webalive.com.au </p></td>
              </tr>
            </table></td>
          <td width="40"></td>
        </tr>
        <tr>
          <td colspan="3" height="25"></td>
        </tr>
        <tr>
          <td width="40"></td>
          <td  align="left" valign="top" style="color:#000000;font-size:18px;text-align:left;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;"><b>Order Details:</b></td>
          <td width="40"></td>
        </tr>
        <tr>
          <td colspan="3" height="15"></td>
        </tr>
        <tr>
          <td width="40"></td>
          <td align="center" valign="top"><table align="center" cellpadding="0" cellspacing="0" width="100%" style="border-right: 1px solid #d7d7d7;">
              <tr>
                <th  align="left" valign="middle" width="10%" style="background-color:#f2f2f2;color:#353535;font-size:15px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:bold;border-top: 1px solid #d7d7d7;border-bottom: 1px solid #d7d7d7;border-left: 1px solid #d7d7d7;padding:5px 0; margin-bottom:0; margin-top:0;">Sl</th>
                <th  align="left" valign="middle" width="10%" style="background-color:#f2f2f2;color:#353535;font-size:15px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:bold;border-top: 1px solid #ccc;border-bottom: 1px solid #d7d7d7;border-left: 1px solid #d7d7d7;padding:5px 0; margin-bottom:0; margin-top:0;">Type</th>
                <th  align="left" valign="middle" width="10%" style="background-color:#f2f2f2;color:#353535;font-size:15px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:bold;border-top: 1px solid #ccc;border-bottom: 1px solid #d7d7d7;border-left: 1px solid #d7d7d7;padding:5px 0; margin-bottom:0; margin-top:0;">Value</th>
                <th  align="left" valign="middle" width="10%" style="background-color:#f2f2f2;color:#353535;font-size:15px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:bold;border-top: 1px solid #ccc;border-bottom: 1px solid #d7d7d7;border-left: 1px solid #d7d7d7;padding:5px 0; margin-bottom:0; margin-top:0;">Price</th>
              </tr>
              <tr>
                <td  align="left" valign="middle" width="10%" style="background-color:#fff;color:#000;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;border-bottom: 1px solid #ccc;border-left: 1px solid #d7d7d7;padding:5px 0; margin-bottom:0; margin-top:0;"><p style="color:#353535;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;padding:0; margin-bottom:0; margin-top:0;">1</p></td>
                <td  align="left" valign="middle" width="10%" style="background-color:#fff;color:#000;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;border-bottom: 1px solid #ccc;border-left: 1px solid #d7d7d7;padding:5px 0; margin-bottom:0; margin-top:0;"><p style="color:#353535;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal; padding:0; margin-bottom:0; margin-top:0;">Subrub</p></td>
                <td  align="left" valign="middle" width="10%" style="background-color:#fff;color:#000;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;border-bottom: 1px solid #ccc;border-left: 1px solid #d7d7d7;padding:5px 0; margin-bottom:0; margin-top:0;"><p style="color:#353535;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;padding:0; margin-bottom:0; margin-top:0;">Yarra</p></td>
                <td  align="left" valign="middle" width="10%" style="background-color:#fff;color:#000;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;border-bottom: 1px solid #ccc;border-left: 1px solid #d7d7d7;padding:5px 0; margin-bottom:0; margin-top:0;">&nbsp;</td>
              </tr>


              <tr>
                <td  align="left" valign="middle" width="10%" style="background-color:#f2f2f2;color:#000;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;border-bottom: 1px solid #ccc;border-left: 1px solid #d7d7d7;padding:5px 0; margin-bottom:0; margin-top:0;"><p style="color:#353535;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;padding:0; margin-bottom:0; margin-top:0;">2</p></td>
                <td  align="left" valign="middle" width="10%" style="background-color:#f2f2f2;color:#000;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;border-bottom: 1px solid #ccc;border-left: 1px solid #d7d7d7;padding:5px 0; margin-bottom:0; margin-top:0;"><p style="color:#353535;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal; padding:0; margin-bottom:0; margin-top:0;">Bin Type</p></td>
                <td  align="left" valign="middle" width="10%" style="background-color:#f2f2f2;color:#000;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;border-bottom: 1px solid #ccc;border-left: 1px solid #d7d7d7;padding:5px 0; margin-bottom:0; margin-top:0;"><p style="color:#353535;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;padding:0; margin-bottom:0; margin-top:0;">660L Wheelie Bin</p></td>
                <td  align="left" valign="middle" width="10%" style="background-color:#f2f2f2;color:#000;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;border-bottom: 1px solid #ccc;border-left: 1px solid #d7d7d7;padding:5px 0; margin-bottom:0; margin-top:0;">$250</td>
              </tr>
              
              
              
              <tr>
                <td  align="left" valign="middle" width="10%" style="background-color:#fff;color:#000;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;border-bottom: 1px solid #ccc;border-left: 1px solid #d7d7d7;padding:5px 0; margin-bottom:0; margin-top:0;"><p style="color:#353535;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;padding:0; margin-bottom:0; margin-top:0;">3</p></td>
                <td  align="left" valign="middle" width="10%" style="background-color:#fff;color:#000;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;border-bottom: 1px solid #ccc;border-left: 1px solid #d7d7d7;padding:5px 0; margin-bottom:0; margin-top:0;"><p style="color:#353535;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal; padding:0; margin-bottom:0; margin-top:0;">Waste Type</p></td>
                <td  align="left" valign="middle" width="10%" style="background-color:#fff;color:#000;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;border-bottom: 1px solid #ccc;border-left: 1px solid #d7d7d7;padding:5px 0; margin-bottom:0; margin-top:0;"><p style="color:#353535;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;padding:0; margin-bottom:0; margin-top:0;">Light Mix(Household Goods, Clothes,Furniture,Electrical,Garden Waste)</p></td>
                <td  align="left" valign="middle" width="10%" style="background-color:#fff;color:#000;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;border-bottom: 1px solid #ccc;border-left: 1px solid #d7d7d7;padding:5px 0; margin-bottom:0; margin-top:0;">&nbsp;</td>
              </tr>




              <tr>
                <td  align="left" valign="middle" width="10%" style="background-color:#f2f2f2;color:#000;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;border-bottom: 1px solid #ccc;border-left: 1px solid #d7d7d7;padding:5px 0; margin-bottom:0; margin-top:0;"><p style="color:#353535;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;padding:0; margin-bottom:0; margin-top:0;">4</p></td>
                <td  align="left" valign="middle" width="10%" style="background-color:#f2f2f2;color:#000;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;border-bottom: 1px solid #ccc;border-left: 1px solid #d7d7d7;padding:5px 0; margin-bottom:0; margin-top:0;"><p style="color:#353535;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal; padding:0; margin-bottom:0; margin-top:0;">Placing</p></td>
                <td  align="left" valign="middle" width="10%" style="background-color:#f2f2f2;color:#000;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;border-bottom: 1px solid #ccc;border-left: 1px solid #d7d7d7;padding:5px 0; margin-bottom:0; margin-top:0;"><p style="color:#353535;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;padding:0; margin-bottom:0; margin-top:0;">Nature Trip</p></td>
                <td  align="left" valign="middle" width="10%" style="background-color:#f2f2f2;color:#000;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;border-bottom: 1px solid #ccc;border-left: 1px solid #d7d7d7;padding:5px 0; margin-bottom:0; margin-top:0;">$50</td>
              </tr>


              <tr>
                <td  align="left" valign="middle" width="10%" style="background-color:#fff;color:#000;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;border-bottom: 1px solid #ccc;border-left: 1px solid #d7d7d7;padding:5px 0; margin-bottom:0; margin-top:0;"><p style="color:#353535;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;padding:0; margin-bottom:0; margin-top:0;">5</p></td>
                <td  align="left" valign="middle" width="10%" style="background-color:#fff;color:#000;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;border-bottom: 1px solid #ccc;border-left: 1px solid #d7d7d7;padding:5px 0; margin-bottom:0; margin-top:0;"><p style="color:#353535;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal; padding:0; margin-bottom:0; margin-top:0;">Duration</p></td>

                <td  align="left" valign="middle" width="10%" style="background-color:#fff;color:#000;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;border-bottom: 1px solid #ccc;border-left: 1px solid #d7d7d7;padding:5px 0; margin-bottom:0; margin-top:0;"><p style="color:#353535;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;padding:0; margin-bottom:0; margin-top:0;">5 Days</p></td>
                <td  align="left" valign="middle" width="10%" style="background-color:#fff;color:#000;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;border-bottom: 1px solid #ccc;border-left: 1px solid #d7d7d7;padding:5px 0; margin-bottom:0; margin-top:0;">&nbsp;</td>
              </tr>



              <tr>
                <td  align="left" valign="middle" width="10%" style="background-color:#f2f2f2;color:#000;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;border-bottom: 1px solid #ccc;border-left: 1px solid #d7d7d7;padding:5px 0; margin-bottom:0; margin-top:0;"><p style="color:#353535;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;padding:0; margin-bottom:0; margin-top:0;">&nbsp;</p></td>
                <td  align="left" valign="middle" width="10%" style="background-color:#f2f2f2;color:#000;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;border-bottom: 1px solid #ccc;border-left: 1px solid #fff;padding:5px 0; margin-bottom:0; margin-top:0;"><p style="color:#353535;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal; padding:0; margin-bottom:0; margin-top:0;">&nbsp;</p></td>
                <td  align="right" valign="middle" width="10%" style="background-color:#f2f2f2;color:#000;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;border-bottom: 1px solid #ccc;border-left: 1px solid #fff;padding:5px 0; margin-bottom:0; margin-top:0;"><p style="color:#000;font-size:14px;text-align:right;font-family:Arial, Helvetica, sans-serif;
font-weight:bold;padding:0; margin-bottom:0; margin-top:0;">GST&nbsp;&nbsp;</p></td>
                <td  align="left" valign="middle" width="10%" style="background-color:#f2f2f2;color:#000;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;border-bottom: 1px solid #ccc;border-left: 1px solid #d7d7d7;padding:5px 0; margin-bottom:0; margin-top:0;">$30</td>
              </tr>


                <tr>
                <td  align="left" valign="middle" width="10%" style="background-color:#f2f2f2;color:#000;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;border-bottom: 1px solid #ccc;border-left: 1px solid #d7d7d7;padding:5px 0; margin-bottom:0; margin-top:0;"><p style="color:#353535;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;padding:0; margin-bottom:0; margin-top:0;">&nbsp;</p></td>
                <td  align="left" valign="middle" width="10%" style="background-color:#f2f2f2;color:#000;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;border-bottom: 1px solid #ccc;border-left: 1px solid #fff;padding:5px 0; margin-bottom:0; margin-top:0;"><p style="color:#353535;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal; padding:0; margin-bottom:0; margin-top:0;">&nbsp;</p></td>
                <td  align="right" valign="middle" width="10%" style="background-color:#f2f2f2;color:#000;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;border-bottom: 1px solid #ccc;border-left: 1px solid #fff;padding:5px 0; margin-bottom:0; margin-top:0;"><p style="color:#000;font-size:14px;text-align:right;font-family:Arial, Helvetica, sans-serif;
font-weight:bold;padding:0; margin-bottom:0; margin-top:0;">TOTAL&nbsp;&nbsp;</p></td>
                <td  align="left" valign="middle" width="10%" style="background-color:#f2f2f2;color:#000;font-size:14px;text-align:center;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;border-bottom: 1px solid #ccc;border-left: 1px solid #d7d7d7;padding:5px 0; margin-bottom:0; margin-top:0;">$300</td>
              </tr>

            
              
              
              
            </table></td>
          <td width="40"></td>
        </tr>
        <tr>
          <td colspan="3" height="40"></td>
        </tr>
        <tr>
          <td width="40"></td>
          <td  align="left" valign="top" style="color:#000;font-size:14px;text-align:left;font-family:Arial, Helvetica, sans-serif;
font-weight:normal;"><b style="font-size:12px;">Regards</b><br />
            <b style="font-size:14px;">Rhinobin Hire Team </b></td>
          <td width="40"></td>
        </tr>
        <tr>
          <td colspan="3" height="40"></td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td align="center" valign="top" height="40"></td>
  </tr>
</table>
</body>
</html>





EOD;








	// To send HTML mail, the Content-type header must be set
	$headers  = 'MIME-Version: 1.0' . "\r\n";
	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
	$headers .= 'To: WebAlive <forms@webalive.biz>' . "\r\n";


	mail($to, $subject, $html, $headers);

?>


 

 