<?php
	$to = 'webalive.srv@gmail.com';
	
 	
	$subject = 'Welcome Autobil';
	
	
$html = <<<EOD



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Newsletter</title>
</head>
<body style="background:#f7f7f7;">
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
<style type="text/css">
*{
	font-family:Open Sans;
}
p,span,a,strong,tabel,tr,th,td{
	font-family:Open Sans;
}
</style>
<table width="100%" border="0" cellspacing="0" cellpadding="0"  bgcolor="#f7f7f7" align="center">
  <tr>
    <td valign="top" align="center"><table width="748" border="0" cellspacing="0" cellpadding="0" bgcolor="#f7f7f7" align="center">
        <tr>
          <td valign="top" align="center" height="30px" style="line-height:30px;"></td>
        </tr>
      </table>
      <table width="748" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center" style="border:1px solid #e2e2e2; padding:2px;">
        <tr>
          <td valign="top" align="center" height="20px" style="line-height:20px;"></td>
        </tr>
        <tr>
          <td valign="top" align="center"><table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center">
              <tr>
                <td width="100%" height="15px"></td>
              </tr>
            </table>
            <table width="100%" cellspacing="0" cellpadding="0" border="0" bgcolor="#ffffff" align="center">
              <tbody>
                <tr>
                  <td width="5%" align="left"></td>
                  <td width="60%" align="left"><a href="#"> <img width="184" height="56" border="0" src="http://larry.webmascot.com/autobil_newsletter/images/company-logo.png" alt="Logo"> </a></td>
                  <td width="30%" align="left"><table width="100%" cellspacing="0" cellpadding="0" border="0" bgcolor="#ffffff" align="center">
                      <tbody>
                        <tr>
                          <td valign="top" align="left"><span style="color:#777777;font-size:18px;text-decoration:none;"> Contact: </span></td>
                          <td valign="top" align="left"><a href="tel:1300 253 181" style="text-decoration:none !important;text-decoration:none;"> <span style="color: rgb(119, 119, 119);text-decoration: none; font-weight: 700; font-size: 20px;"> 1300 253 181 </span></a></td>
                        </tr>
                      </tbody>
                    </table></td>
                  <td width="5%" align="left"></td>
                </tr>
              </tbody>
            </table>
            <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#fff" align="center">
              <tr>
                <td width="100%" height="25px"></td>
              </tr>
            </table>
            <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center">
              <tr>
                <td width="4%" valign="top"></td>
                <td width="92%" valign="top"><p style="background:#eee;line-height:7px;height:7px;">&nbsp;</p></td>
                <td width="4%" valign="top"></td>
              </tr>
            </table>
            <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#fff" align="center">
              <tr>
                <td width="100%" height="50px"></td>
              </tr>
            </table>
            <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#fff" align="center">
              <tr>
                <td width="100%" align="center" style="padding:15px 0;"><span style="color: #595959; font-size: 25px; font-weight: 400;"> Your demo schedule is almost set</span></td>
              </tr>
            </table>
            <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center">
              <tr>
                <td  width="100%" height="40px">&nbsp;</td>
              </tr>
            </table>
            <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center">
              <tr>
                <td width="4%" valign="top"></td>
                <td width="96%" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
                    <tr>
                      <td valign="top" align="left"><p style="line-height:16px;"><span style="color:#595959;font-size:18px; text-decoration:underline;">Thank you for your interest to showcase our AutoBill</span></p></td>
                    </tr>
                    <tr>
                      <td height="30px"></td>
                    </tr>
                  </table></td>
              </tr>
            </table>
            <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center">
              <tr>
                <td width="4%" valign="top"></td>
                <td width="96%" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center">
                    <tr>
                      <td width="100%" valign="top"><p><strong><span style="color:#595959;font-size:18px;font-weight:600;"> Dear (xyz)</span></strong></p>
                        <p style="line-height:22px;"><span style="color:#595959;font-size:15px;">The great is yet to come when meet to benefit your business. </span></p>
                        <p style="line-height:22px;"><span style="color:#595959;font-size:15px;">We have received your request to showcase AutoBill. One of our expert consultants will be in touch with you so schedule the demo a time convenient to you.</span></p>
                        <p style="line-height:22px;"><span style="color:#595959;font-size:15px;">During the demo, we will give you the overview and walk you through the basics of AutoBill system, answer your questions. And if decide to go ahead with the system, we will assist you on that too so that you are comfortable, confident the system you are purchasing.</span></p>
                        <p style="line-height:22px;"><span style="color:#595959;font-size:15px;">Talk to you soon.</span></p>
                        <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center">
                          <tr>
                            <td width="100%" valign="top" height="30px" style="line-height:30px;">&nbsp;</td>
                          </tr>
                          <tr>
                            <td width="100%" valign="top"><span style="color:#595959;font-size:15px;"> Regards,</span></td>
                          </tr>
                          <tr>
                            <td width="100%" valign="top" height="8px" style="line-height:8px;">&nbsp;</td>
                          </tr>
                          <tr>
                            <td width="100%" valign="top"><span style="color:#595959;font-size:18px;font-weight:600;"> AutoBill Team</span></td>
                          </tr>
                          <tr>
                            <td width="100%"  valign="top" height="20px" style="line-height:60px;">&nbsp;</td>
                          </tr>
                          <tr>
                            <td width="100%" valign="top"><span style="color:#005693;font-size:18px;"> Got any question?.</span></td>
                          </tr>
                          <tr>
                            <td width="100%" valign="top"><span style="color:#005693;font-size:18px;"> Happy to help.</span></td>
                          </tr>
                          <tr>
                            <td width="100%" valign="top" height="8px" style="line-height:30px;">&nbsp;</td>
                          </tr>
                          <tr>
                            <td width="100%" valign="top"><span style="color:#595959;font-size:15px;"> We have 24/7 Support team to keep you going.</span></td>
                          </tr>
                          <tr>
                            <td width="100%" valign="top"><span style="color:#595959;font-size:15px;"> Contact: <a href="tel:1300 253 181" style="color:#595959; text-decoration:none;">1300 253 181</a> or see Help Center.</span></td>
                          </tr>
                          <tr>
                            <td width="100%"  valign="top" height="20px" style="line-height:20px;">&nbsp;</td>
                          </tr>
                        </table>
                        <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center">
                          <tr>
                            <td valign="top" align="left"><span style="color:#595959;font-size:13px;"> P: <a href="tel:1300 253 181" style="color:#595959; text-decoration:none;">1300 253 181</a> | E: <a href="mailto:support@autobill.com "  style="color:#005693; text-decoration:none;">support@autobill.com </a></span></td>
                          </tr>
                          <tr>
                            <td valign="top" align="left"><span style="color:#595959;font-size:13px;"> <a href="https://www.facebook.com/AutoBill" target="_blank"  style="color:#005693;text-decoration:none;">Facebook </a> | <a href="https://twitter.com/AutoBillTeam" target="_blank"  style="color:#005693;text-decoration:none;">Twitter</a>| <a href="https://plus.google.com/u/0/115765267571488537138/posts" target="_blank"  style="color:#005693;text-decoration:none;">Google+ </a>| <a href="https://www.linkedin.com/company/autobill" target="_blank"  style="color:#005693;text-decoration:none;">LinkedIn</a></td>
                          </tr>
                        </table>
                        <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center">
                          <tr>
                            <td width="100%" colspan="2" valign="top" height="20px" style="line-height:20px;">&nbsp;</td>
                          </tr>
                          <tr>
                            <td width="100%" colspan="2" valign="top"><img src="http://larry.webmascot.com/autobil_newsletter/images/line-shded.png"  border="0"  alt="line" width="677" height="1"   /></td>
                          </tr>
                          <tr>
                            <td width="100%" colspan="2" valign="top" height="20px" style="line-height:20px;">&nbsp;</td>
                          </tr>
                        </table>
                        <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center">
                          <tr>
                            <td valign="top" align="left" width="95%"><p style="text-align:justify; line-height:18px;"><span style="color:#8d8d8d;font-size:12px; text-align:justify;">Disclaimer: Privileged/Confidential information may be contained in this message and may be subject to legal privilege. Access to this e-mail by anyone other than the intended is unauthorised. If you are not the intended recipient (or responsible for delivery of the message to such person), you may not use, copy, distribute or deliver to anyone this message (or any part of its contents) or take any action in reliance on it. In such case, you should destroy this message, and notify us immediately. If you have received this email in error, please notify us immediately by e-mail or telephone and delete the e-mail from any compute</span> </p></td>
                            <td valign="top" align="left" width="5%">&nbsp;</td>
                          </tr>
                        </table>
                        <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center">
                          <tr>
                            <td width="100%" colspan="2" valign="top" height="100px" style="line-height:100px;">&nbsp;</td>
                          </tr>
                        </table></td>
                    </tr>
                  </table></td>
              </tr>
            </table></td>
        </tr>
      </table>
      <table width="748" border="0" cellspacing="0" cellpadding="0" bgcolor="#f7f7f7" align="center">
        <tr>
          <td valign="top" align="center" height="70px" style="line-height:70px;"></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>



EOD;








	// To send HTML mail, the Content-type header must be set
	$headers  = 'MIME-Version: 1.0' . "\r\n";
	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
	$headers .= 'To: WebAlive <forms@webalive.biz>' . "\r\n";


	mail($to, $subject, $html, $headers);

?>


 

 