<?php
 	
	$to = 'webalive.srv@gmail.com';
 	
	$subject = 'Welcome Autobil';
	
	
$html = <<<EOD


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>start-autobil::Newsletter</title>
</head>
<body style="background:#f7f7f7;">
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
<style type="text/css">
*{
	font-family:Open Sans;
}
p,span,a,strong,tabel,tr,th,td{
	font-family:Open Sans;
}
</style>
<table width="100%" border="0" cellspacing="0" cellpadding="0"  bgcolor="#f7f7f7" align="center">
  <tr>
    <td valign="top" align="center"><table width="748" border="0" cellspacing="0" cellpadding="0" bgcolor="#f7f7f7" align="center">
        <tr>
          <td valign="top" align="center" height="30px" style="line-height:30px;"></td>
        </tr>
      </table>
      <table width="748" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center" style="border:1px solid #e2e2e2; padding:2px;">
        <tr>
          <td valign="top" align="center" height="20px" style="line-height:20px;"></td>
        </tr>
        <tr>
          <td valign="top" align="center"><table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center">
              <tr>
                <td width="100%" height="15px"></td>
              </tr>
            </table>
            <table width="100%" cellspacing="0" cellpadding="0" border="0" bgcolor="#ffffff" align="center">
              <tbody>
                <tr>
                  <td width="5%" align="left"></td>
                  <td width="60%" align="left"><a href="http://www.autobill.com/"> <img width="184" height="56" border="0" src="http://larry.webmascot.com/autobil_newsletter/images/company-logo.png" alt="Logo"> </a></td>
                  <td width="30%" align="left"><table width="100%" cellspacing="0" cellpadding="0" border="0" bgcolor="#ffffff" align="center">
                      <tbody>
                        <tr>
                          <td valign="top" align="left"><span style="color:#777777;font-size:18px;text-decoration:none;"> Contact: </span></td>
                          <td valign="top" align="left"><a href="tel:1300 253 181" style="text-decoration:none !important;text-decoration:none;"> <span style="color: rgb(119, 119, 119);text-decoration: none; font-weight: 700; font-size: 20px;"> 1300 253 181 </span></a></td>
                        </tr>
                      </tbody>
                    </table></td>
                  <td width="5%" align="left"></td>
                </tr>
              </tbody>
            </table>
            <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#fff" align="center">
              <tr>
                <td width="100%" height="25px"></td>
              </tr>
            </table>
            <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center">
              <tr>
                <td width="4%" valign="top"></td>
                <td width="92%" valign="top"><p style="background:#eee;line-height:7px;height:7px;">&nbsp;</p></td>
                <td width="4%" valign="top"></td>
              </tr>
            </table>
             
             
            <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center">
              <tr>
                <td  width="100%" height="30px">&nbsp;</td>
              </tr>
            </table>
             
             
            <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center">
              <tr>
                <td width="4%" valign="top"></td>
                <td width="92%" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center">
                    <tr>
                      <td width="100%" valign="top"><p><strong><span style="color:#595959;font-size:18px;font-weight:600;"> Dear (xyz)</span></strong></p>
 <p style="line-height:22px;"><span style="color:#595959;font-size:15px;">Welcome to AutoBill!</span></p>
<p style="line-height:22px;"><span style="color:#595959;font-size:15px;">Thank you for signing up with us.</span></p>
<p style="line-height:22px;"><span style="color:#595959;font-size:15px;">We have built AutoBill to simplify your business complexities and help facilitate the growth of your business.</span></p>
<p style="line-height:22px;"><span style="color:#595959;font-size:15px;">Please find your credentials below for your future reference:</span></p>
<p style="line-height:22px;"><span style="color:#595959;font-size:15px;">Login name: [email address]</span></p>
<p style="line-height:22px;"><span style="color:#595959;font-size:15px;">Password: abc123 </span></p>
<p style="line-height:22px;"><span style="color:#595959;font-size:15px;">Getting started is easy, you can simply follow the Start-up wizard and configure in few simple clicks.</span></p> 

<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center">
<tr> <td width="100%" valign="top" height="30px" style="line-height:30px;">&nbsp;</td> </tr>
</table>                        
<p style="line-height:22px; text-align:center;"><span style="color:#005693;font-size:18px; text-decoration:underline;">Start Exploring AutoBill</span></p>
<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center">
<tr> <td width="100%" valign="top" height="30px" style="line-height:30px;">&nbsp;</td> </tr>
</table>                        


<p style="line-height:22px;"><span style="color:#595959;font-size:15px;">We also offer free live demo at a time convenient to you so that we can walk you through the great features of the software and answer any questions you may have, just get in tough to find out more.</span></p>

<p style="line-height:22px;"><span style="color:#595959;font-size:15px;">You have 14 days trail period from the date of to explore the system and if you decide to go ahead with the service, you can continue using the data that you created during your trial. </span></p>

<p style="line-height:22px;"><span style="color:#595959;font-size:15px;">If you have any questions during the trial, please feel free to contact us or 
visit <a style="color:#005693;font-size:18px; text-decoration:underline;" href="http://autobill.com.au/" target="_blank">website-</a> we are here to help!</span></p>

<p style="line-height:22px;"><span style="color:#595959;font-size:15px;">We look forward to helping you grow your business.</span></p>


<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center">
<tr> <td width="100%" valign="top" height="30px" style="line-height:30px;">&nbsp;</td> </tr>
</table>                        
                        
                        
                       
                        <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center">
                          <tr>
                            <td width="100%" valign="top" height="30px" style="line-height:30px;">&nbsp;</td>
                          </tr>
                          <tr>
                            <td width="100%" valign="top"><span style="color:#595959;font-size:15px;"> Regards,</span></td>
                          </tr>
                          <tr>
                            <td width="100%" valign="top" height="8px" style="line-height:8px;">&nbsp;</td>
                          </tr>
                          <tr>
                            <td width="100%" valign="top"><span style="color:#595959;font-size:18px;font-weight:600;"> AutoBill Team</span></td>
                          </tr>
                          <tr>
                            <td width="100%"  valign="top" height="20px" style="line-height:60px;">&nbsp;</td>
                          </tr>
                          <tr>
                            <td width="100%" valign="top"><span style="color:#005693;font-size:18px;"> Got any question?.</span></td>
                          </tr>
                          <tr>
                            <td width="100%" valign="top"><span style="color:#005693;font-size:18px;"> Happy to help.</span></td>
                          </tr>
                          <tr>
                            <td width="100%" valign="top" height="8px" style="line-height:30px;">&nbsp;</td>
                          </tr>
                          <tr>
                            <td width="100%" valign="top"><span style="color:#595959;font-size:15px;"> We have 24/7 Support team to keep you going.</span></td>
                          </tr>
                          <tr>
                            <td width="100%" valign="top"><span style="color:#595959;font-size:15px;"> Contact: <a href="tel:1300 253 181" style="color:#595959; text-decoration:none;">1300 253 181</a> or see Help Center.</span></td>
                          </tr>
                          <tr>
                            <td width="100%"  valign="top" height="20px" style="line-height:20px;">&nbsp;</td>
                          </tr>
                        </table>
                        <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center">
                          <tr>
                            <td valign="top" align="left"><span style="color:#595959;font-size:13px;"> P: <a href="tel:1300 253 181" style="color:#595959; text-decoration:none;">1300 253 181</a> | E: <a href="mailto:support@autobill.com "  style="color:#005693; text-decoration:none;">support@autobill.com </a></span></td>
                          </tr>
                          <tr>
                            <td valign="top" align="left"><span style="color:#595959;font-size:13px;"> <a href="https://www.facebook.com/AutoBill" target="_blank"  style="color:#005693;text-decoration:none;">Facebook </a> | <a href="https://twitter.com/AutoBillTeam" target="_blank"  style="color:#005693;text-decoration:none;">Twitter</a>| <a href="https://plus.google.com/u/0/115765267571488537138/posts" target="_blank"  style="color:#005693;text-decoration:none;">Google+ </a>| <a href="https://www.linkedin.com/company/autobill" target="_blank"  style="color:#005693;text-decoration:none;">LinkedIn</a></td>
                          </tr>
                        </table>
                        <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center">
                          <tr>
                            <td width="100%" colspan="2" valign="top" height="20px" style="line-height:20px;">&nbsp;</td>
                          </tr>
                         
                          <tr>
                            <td width="100%" colspan="2" valign="top" height="20px" style="line-height:20px;">&nbsp;</td>
                          </tr>
                        </table>
                        
                       </td>
                    </tr>
                  </table></td>
                  <td width="4%" valign="top"></td>
              </tr>
            </table></td>
        </tr>
      </table>
      <table width="748" border="0" cellspacing="0" cellpadding="0" bgcolor="#f7f7f7" align="center">
        <tr>
          <td valign="top" align="center" height="70px" style="line-height:70px;"></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>


EOD;








	// To send HTML mail, the Content-type header must be set
	$headers  = 'MIME-Version: 1.0' . "\r\n";
	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
	$headers .= 'To: WebAlive <forms@webalive.biz>' . "\r\n";


	mail($to, $subject, $html, $headers);

?>


 

 